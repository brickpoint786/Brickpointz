"use client";

import { useState } from "react";
import { X } from "lucide-react";

interface WhatsAppButtonProps {
  productName: string;
  category: string;
  price: string;
  productUrl?: string;
  variant?: "primary" | "outline" | "small";
  className?: string;
}

const WhatsAppIcon = ({ size = 18 }: { size?: number }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

export default function WhatsAppButton({
  productName,
  category,
  price,
  variant = "primary",
  className = "",
}: WhatsAppButtonProps) {
  const [showModal, setShowModal] = useState(false);
  const [quantity, setQuantity] = useState("");
  const [location, setLocation] = useState("");
  const [extraMessage, setExtraMessage] = useState("");

  const buildMessage = () => {
    const priceText = price === "Price on Request"
      ? "Please share the latest price and availability."
      : `Price: ${price}`;

    let msg = `Assalam-o-Alaikum BrickPoint,\nI am interested in the following product:\n\nProduct: ${productName}\nCategory: ${category}\n${priceText}`;
    if (quantity) msg += `\nQuantity: ${quantity}`;
    if (location) msg += `\nDelivery Location: ${location}`;
    if (extraMessage) msg += `\n\nAdditional Info: ${extraMessage}`;
    msg += `\n\nPlease share availability, delivery details, and final quotation.\nThank you.`;
    return encodeURIComponent(msg);
  };

  const handleOrder = () => {
    const msg = buildMessage();
    window.open(`https://wa.me/923152850818?text=${msg}`, "_blank");
    setShowModal(false);
  };

  const buttonClasses = {
    primary: "inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-semibold px-5 py-2.5 rounded-lg transition-all duration-200 text-sm",
    outline: "inline-flex items-center gap-2 border-2 border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white font-semibold px-5 py-2.5 rounded-lg transition-all duration-200 text-sm",
    small: "inline-flex items-center gap-1.5 bg-[#25D366] hover:bg-[#1da855] text-white font-medium px-3 py-1.5 rounded transition-all duration-200 text-xs",
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className={`${buttonClasses[variant]} ${className}`}
      >
        <WhatsAppIcon size={variant === "small" ? 14 : 18} />
        {variant === "small" ? "Order" : "Order on WhatsApp"}
      </button>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="p-5 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-[#0f1f3d] text-lg">Order on WhatsApp</h3>
                <p className="text-sm text-gray-500 mt-0.5">{productName}</p>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Quantity <span className="text-gray-400">(optional)</span>
                </label>
                <input
                  type="text"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="e.g., 10,000 bricks / 5 bags"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#c0392b] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Delivery Location <span className="text-gray-400">(optional)</span>
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g., DHA Lahore, Bahria Town"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#c0392b] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Additional Message <span className="text-gray-400">(optional)</span>
                </label>
                <textarea
                  value={extraMessage}
                  onChange={(e) => setExtraMessage(e.target.value)}
                  placeholder="Any specific requirements or questions..."
                  rows={3}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#c0392b] focus:border-transparent resize-none"
                />
              </div>
            </div>
            <div className="p-5 border-t border-gray-100 flex gap-3">
              <button
                onClick={() => setShowModal(false)}
                className="flex-1 py-2.5 border border-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleOrder}
                className="flex-1 py-2.5 bg-[#25D366] hover:bg-[#1da855] text-white rounded-lg text-sm font-semibold transition-colors flex items-center justify-center gap-2"
              >
                <WhatsAppIcon size={16} />
                Send on WhatsApp
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
