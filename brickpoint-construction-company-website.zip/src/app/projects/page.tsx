import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { MapPin, ArrowRight, Info } from "lucide-react";
import { db } from "@/db";
import { projects } from "@/db/schema";

export const metadata: Metadata = {
  title: "Projects | BrickPoint — Construction Material Showcases",
  description:
    "Explore featured construction projects and material showcases by BrickPoint. SS7 bricks in residential and commercial construction.",
};

const projectsData = [
  {
    title: "Modern Residential Villa — DHA Lahore",
    slug: "modern-villa-dha-lahore",
    category: "Residential",
    location: "DHA Lahore",
    description:
      "A modern residential villa featuring premium SS7 brickwork and quality construction materials. The clean brick facade showcases consistent quality and professional execution.",
    image: "/images/construction-project.jpg",
    materials: ["SS7 Bricks", "Cement", "Steel", "Sand", "Crush"],
    illustrative: true,
  },
  {
    title: "Commercial Development — Bahria Town Lahore",
    slug: "commercial-development-bahria-town",
    category: "Commercial",
    location: "Bahria Town Lahore",
    description:
      "A multi-storey commercial building project utilizing quality construction materials including bricks, cement, and structural steel for a robust and durable structure.",
    image: "/images/hero-bricks.jpg",
    materials: ["Bricks", "Cement", "Steel Rebar", "Construction Chemicals"],
    illustrative: true,
  },
  {
    title: "Residential Housing — Lake City Lahore",
    slug: "housing-project-lake-city",
    category: "Residential",
    location: "Lake City Lahore",
    description:
      "Premium residential construction featuring quality brickwork and modern construction materials in one of Lahore's premium residential communities.",
    image: "/images/brick-factory.jpg",
    materials: ["SS7 Bricks", "Cement", "Plumbing Pipes", "Paints"],
    illustrative: true,
  },
  {
    title: "Expert Brickwork — Etihad Town Lahore",
    slug: "brickwork-etihad-town",
    category: "Brickwork / Masonry",
    location: "Etihad Town Lahore",
    description:
      "Precision masonry and brickwork using SS7 branded bricks, demonstrating the consistent quality and clean finish achievable with properly sourced construction bricks.",
    image: "/images/bricks-stacked.jpg",
    materials: ["SS7 Bricks", "Cement", "Sand"],
    illustrative: true,
  },
  {
    title: "Villa Construction — Al-Kabir Town Lahore",
    slug: "villa-construction-al-kabir",
    category: "Residential",
    location: "Al-Kabir Town Lahore",
    description:
      "Double-storey residential villa construction featuring quality brick masonry, structural steel, and comprehensive construction material supply.",
    image: "/images/construction-project.jpg",
    materials: ["Bricks", "Steel", "Cement", "Crush"],
    illustrative: true,
  },
  {
    title: "Construction Project — Paragon City Lahore",
    slug: "construction-paragon-city",
    category: "Residential",
    location: "Paragon City Lahore",
    description:
      "Residential construction project featuring quality masonry and modern construction material application for a premium community development.",
    image: "/images/about-team.jpg",
    materials: ["Bricks", "Cement", "Sand", "Steel"],
    illustrative: true,
  },
];

const categories = ["All", "Residential", "Commercial", "Brickwork / Masonry"];

export default async function ProjectsPage() {
  let dbProjects: typeof projects.$inferSelect[] = [];
  try {
    dbProjects = await db.select().from(projects).orderBy(projects.sortOrder);
  } catch (_e) {
    // Use static data
  }

  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-14 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/construction-project.jpg"
            alt="Projects"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/80" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Projects</span>
          </nav>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Construction Showcases
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl">
            Explore featured construction project inspirations showcasing quality brickwork
            and construction material applications.
          </p>
        </div>
      </section>

      {/* Disclaimer */}
      <div className="bg-[#f0ebe3] border-b border-amber-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
          <div className="flex items-start gap-2 text-amber-800 text-sm">
            <Info size={16} className="flex-shrink-0 mt-0.5" />
            <p>
              <strong>Note:</strong> Projects marked as &quot;Illustrative&quot; are representative construction showcases
              for inspiration purposes. They do not represent confirmed BrickPoint client projects
              or official supply agreements with the mentioned communities.
            </p>
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      <section className="py-14 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          {/* Category filter — static display */}
          <div className="flex gap-2 overflow-x-auto pb-4 mb-10 scrollbar-hide">
            {categories.map((cat) => (
              <span
                key={cat}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium border cursor-default ${
                  cat === "All"
                    ? "bg-[#0f1f3d] text-white border-[#0f1f3d]"
                    : "bg-white text-gray-700 border-gray-200"
                }`}
              >
                {cat}
              </span>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {projectsData.map((project) => (
              <div
                key={project.slug}
                className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300"
              >
                <div className="relative h-56 overflow-hidden">
                  <Image
                    src={project.image}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f1f3d]/60 to-transparent" />
                  <div className="absolute top-3 left-3 flex gap-2">
                    <span className="bg-[#c0392b] text-white text-xs font-semibold px-3 py-1 rounded-full">
                      {project.category}
                    </span>
                    {project.illustrative && (
                      <span className="bg-white/90 text-gray-600 text-[10px] font-medium px-2 py-1 rounded-full">
                        Illustrative
                      </span>
                    )}
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-[#0f1f3d] text-base leading-snug mb-2">
                    {project.title}
                  </h3>
                  <div className="flex items-center gap-1 text-gray-500 text-xs mb-3">
                    <MapPin size={12} />
                    {project.location}
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-2">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {project.materials.slice(0, 3).map((mat) => (
                      <span
                        key={mat}
                        className="bg-[#f0ebe3] text-[#0f1f3d] text-xs px-2 py-0.5 rounded font-medium"
                      >
                        {mat}
                      </span>
                    ))}
                    {project.materials.length > 3 && (
                      <span className="text-gray-400 text-xs py-0.5">
                        +{project.materials.length - 3} more
                      </span>
                    )}
                  </div>
                  <a
                    href={`https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20saw%20the%20${encodeURIComponent(project.category)}%20project%20showcase%20and%20would%20like%20to%20discuss%20material%20requirements%20for%20my%20project.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-[#25D366] text-sm font-medium hover:text-[#1da855] transition-colors"
                  >
                    Inquire for Similar Project <ArrowRight size={12} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Materials we supply */}
      <section className="py-14 bg-[#0f1f3d]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-white mb-3">
              Materials We Supply for Projects
            </h2>
            <p className="text-gray-400">
              BrickPoint supplies quality construction materials for all project types
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { name: "SS7 Bricks", icon: "🧱" },
              { name: "Cement", icon: "🏗️" },
              { name: "Steel", icon: "🔩" },
              { name: "Sand & Crush", icon: "⛏️" },
            ].map((mat) => (
              <div
                key={mat.name}
                className="bg-white/5 border border-white/10 rounded-xl p-5 text-center hover:bg-white/10 transition-colors"
              >
                <div className="text-3xl mb-2">{mat.icon}</div>
                <p className="text-white font-semibold">{mat.name}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              href="/products"
              className="inline-flex items-center gap-2 bg-[#c0392b] hover:bg-[#96281b] text-white font-semibold px-7 py-3.5 rounded-xl transition-all"
            >
              View All Products <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-14 bg-[#c0392b]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Starting a Construction Project?
          </h2>
          <p className="text-red-100 text-lg mb-8">
            Contact BrickPoint for SS7 bricks and quality construction materials for your project.
          </p>
          <a
            href="https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20am%20planning%20a%20construction%20project%20and%20need%20materials.%20Please%20assist."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 bg-white text-[#c0392b] hover:bg-gray-100 font-bold px-10 py-4 rounded-xl transition-all duration-200 text-base"
          >
            Discuss Your Project on WhatsApp
          </a>
        </div>
      </section>
    </>
  );
}
