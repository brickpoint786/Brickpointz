import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { MapPin, Navigation, Building2, Phone, ExternalLink } from "lucide-react";
import { LOCATIONS } from "@/lib/data";

export const metadata: Metadata = {
  title: "Locations | BrickPoint — Brick Factory & Office Locations",
  description:
    "Find BrickPoint locations including Masha Allah Bricks Company at Ram Thaman, Fine Bricks Company at Raja Jang, and the BrickPoint Office. Get directions on Google Maps.",
};

export default function LocationsPage() {
  const factories = LOCATIONS.filter((l) => l.type === "factory");
  const offices = LOCATIONS.filter((l) => l.type === "office");

  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-14 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/brick-factory.jpg"
            alt="Our Locations"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/80" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Locations</span>
          </nav>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Find Us
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl">
            Visit our brick factories or contact us for delivery to your construction site.
            Multiple locations for your convenience.
          </p>
        </div>
      </section>

      {/* Factory Locations */}
      <section className="py-14 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="mb-12">
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              Manufacturing Facilities
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-4">
              Our Brick Factory Locations
            </h2>
            <p className="text-gray-600 text-lg">
              BrickPoint operates three brick manufacturing facilities (bhattas) producing
              SS7 bricks and quality construction materials.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {factories.map((location) => (
              <div
                key={location.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group"
              >
                {/* Map Preview */}
                <div className="relative h-48 bg-[#0f1f3d] overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-[#c0392b] rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                        <MapPin size={28} className="text-white" />
                      </div>
                      <p className="text-white font-semibold text-sm">{location.area || "View on Map"}</p>
                    </div>
                  </div>
                  <div className="absolute inset-0 opacity-20">
                    <Image
                      src="/images/brick-factory.jpg"
                      alt={location.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  {/* Company type badge */}
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#c0392b] text-white text-xs font-bold px-3 py-1 rounded uppercase tracking-wide">
                      Brick Factory
                    </span>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-10 h-10 bg-[#c0392b]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Building2 size={20} className="text-[#c0392b]" />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#0f1f3d] text-base leading-snug">
                        {location.name}
                      </h3>
                      <p className="text-[#c0392b] text-xs font-medium mt-0.5">
                        {location.company}
                      </p>
                    </div>
                  </div>

                  {location.area && (
                    <div className="flex items-center gap-2 text-gray-600 text-sm mb-5">
                      <MapPin size={14} className="text-[#c0392b]" />
                      <span>{location.area}</span>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <a
                      href={location.mapsLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 bg-[#0f1f3d] hover:bg-[#1a3260] text-white font-semibold py-2.5 rounded-lg transition-all text-sm"
                    >
                      <Navigation size={14} />
                      Get Directions
                    </a>
                    <a
                      href="tel:03152850818"
                      className="flex-shrink-0 inline-flex items-center justify-center gap-1 border-2 border-[#0f1f3d] text-[#0f1f3d] hover:bg-[#0f1f3d] hover:text-white font-semibold py-2.5 px-3 rounded-lg transition-all text-sm"
                    >
                      <Phone size={14} />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Office Location */}
      <section className="py-14 bg-[#f0ebe3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="mb-10">
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              Main Office
            </p>
            <h2 className="text-3xl font-bold text-[#0f1f3d]">BrickPoint Office</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {offices.map((office) => (
              <div
                key={office.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="relative h-56 bg-[#0f1f3d]">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-[#c0392b] rounded-full flex items-center justify-center mx-auto mb-3 shadow-xl">
                        <Building2 size={32} className="text-white" />
                      </div>
                      <p className="text-white font-bold text-lg">BrickPoint Office</p>
                    </div>
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-[#0f1f3d] mb-4">{office.name}</h3>
                  <p className="text-gray-600 mb-6">
                    Main office for BrickPoint — handling sales, inquiries, and customer support.
                  </p>
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center gap-3">
                      <Phone size={18} className="text-[#c0392b]" />
                      <div>
                        <p className="text-xs text-gray-500">Phone / WhatsApp</p>
                        <a href="tel:03152850818" className="text-[#0f1f3d] font-semibold hover:text-[#c0392b] transition-colors">
                          03152850818
                        </a>
                      </div>
                    </div>
                  </div>
                  <a
                    href={office.mapsLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-[#0f1f3d] hover:bg-[#1a3260] text-white font-semibold px-6 py-3 rounded-xl transition-all"
                  >
                    <Navigation size={16} />
                    Get Directions
                    <ExternalLink size={14} />
                  </a>
                </div>
              </div>
            ))}

            {/* Contact card */}
            <div className="bg-[#0f1f3d] rounded-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-2">Need Help Finding Us?</h3>
              <p className="text-gray-300 mb-6">
                Contact our sales team on WhatsApp or phone for directions and delivery arrangements.
              </p>
              <div className="space-y-4 mb-6">
                <div>
                  <p className="text-gray-400 text-xs uppercase tracking-wide mb-1">CEO</p>
                  <p className="font-semibold">Syed Iftikhar Haider</p>
                </div>
                <div>
                  <p className="text-gray-400 text-xs uppercase tracking-wide mb-1">Sales Manager</p>
                  <p className="font-semibold">Qasim Iqbal</p>
                </div>
                <div>
                  <p className="text-gray-400 text-xs uppercase tracking-wide mb-1">Phone / WhatsApp</p>
                  <a href="tel:03152850818" className="font-semibold text-xl hover:text-[#c0392b] transition-colors">
                    03152850818
                  </a>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/923152850818"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-semibold py-3 rounded-xl transition-all text-sm"
                >
                  WhatsApp Us
                </a>
                <a
                  href="tel:03152850818"
                  className="flex-1 inline-flex items-center justify-center gap-2 border-2 border-white/20 hover:border-white/50 text-white font-semibold py-3 rounded-xl transition-all text-sm"
                >
                  <Phone size={15} />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map summary */}
      <section className="py-14 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-[#0f1f3d] mb-3">All Locations at a Glance</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {LOCATIONS.map((loc) => (
              <a
                key={loc.id}
                href={loc.mapsLink}
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-white rounded-xl border border-gray-100 p-5 hover:shadow-lg hover:border-[#c0392b]/30 transition-all duration-300"
              >
                <div className="flex items-center gap-2 mb-3">
                  <MapPin size={16} className="text-[#c0392b]" />
                  <span className="text-xs font-semibold uppercase tracking-wide text-[#c0392b]">
                    {loc.type === "office" ? "Office" : "Factory"}
                  </span>
                </div>
                <h3 className="font-bold text-[#0f1f3d] text-sm mb-1 leading-snug">
                  {loc.name}
                </h3>
                {loc.area && (
                  <p className="text-gray-500 text-xs">{loc.area}</p>
                )}
                <div className="mt-3 text-[#c0392b] text-xs font-medium group-hover:gap-2 flex items-center gap-1 transition-all">
                  Open in Maps <ExternalLink size={10} />
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
