import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Clock, User, Calendar, ArrowLeft, ArrowRight } from "lucide-react";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { eq, desc, ne } from "drizzle-orm";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  try {
    const post = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.slug, slug))
      .limit(1);
    if (post.length) {
      return {
        title: `${post[0].title} | BrickPoint Blog`,
        description: post[0].excerpt || "",
      };
    }
  } catch (_e) {}
  return { title: "Blog Post | BrickPoint" };
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;

  let post: typeof blogPosts.$inferSelect | null = null;
  let relatedPosts: typeof blogPosts.$inferSelect[] = [];

  try {
    const result = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.slug, slug))
      .limit(1);

    if (!result.length || !result[0].published) notFound();
    post = result[0];

    relatedPosts = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.published, true))
      .orderBy(desc(blogPosts.createdAt))
      .limit(4);
    relatedPosts = relatedPosts.filter((p) => p.slug !== slug).slice(0, 3);
  } catch (_e) {
    notFound();
  }

  if (!post) notFound();

  return (
    <>
      {/* Header */}
      <div className="bg-[#0f1f3d] py-10 md:py-14 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src={post.featuredImage || "/images/bricks-stacked.jpg"}
            alt={post.title}
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/80" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6 flex-wrap">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/blog" className="hover:text-white transition-colors">Blog</Link>
            <span>/</span>
            <span className="text-white line-clamp-1">{post.title}</span>
          </nav>
          {post.category && (
            <span className="inline-block bg-[#c0392b] text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide mb-4">
              {post.category}
            </span>
          )}
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
            {post.title}
          </h1>
          <div className="flex flex-wrap items-center gap-6 text-gray-300 text-sm">
            <div className="flex items-center gap-2">
              <User size={14} />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock size={14} />
              <span>{post.readingTime} min read</span>
            </div>
            {post.createdAt && (
              <div className="flex items-center gap-2">
                <Calendar size={14} />
                <span>
                  {new Date(post.createdAt).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      <article className="py-12 md:py-16 bg-[#faf8f5]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          {/* Featured image */}
          {post.featuredImage && (
            <div className="relative rounded-2xl overflow-hidden shadow-xl mb-10">
              <Image
                src={post.featuredImage}
                alt={post.title}
                width={900}
                height={500}
                className="w-full h-64 md:h-96 object-cover"
              />
            </div>
          )}

          {/* Excerpt */}
          {post.excerpt && (
            <div className="bg-[#f0ebe3] border-l-4 border-[#c0392b] rounded-r-xl p-5 mb-8">
              <p className="text-[#0f1f3d] font-medium leading-relaxed">{post.excerpt}</p>
            </div>
          )}

          {/* Content */}
          {post.content && (
            <div
              className="prose prose-lg max-w-none text-gray-700 leading-relaxed
                prose-headings:text-[#0f1f3d] prose-headings:font-bold
                prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4
                prose-p:mb-5 prose-p:leading-relaxed"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          )}

          {/* CTA within article */}
          <div className="mt-12 bg-[#0f1f3d] rounded-2xl p-8 text-center">
            <h3 className="text-white font-bold text-xl mb-3">
              Need Construction Materials?
            </h3>
            <p className="text-gray-300 mb-6">
              BrickPoint supplies SS7 bricks and quality construction materials. Order on WhatsApp for pricing and availability.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/923152850818"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold px-7 py-3 rounded-xl transition-all"
              >
                Order on WhatsApp
              </a>
              <Link
                href="/products"
                className="inline-flex items-center justify-center gap-2 bg-[#c0392b] hover:bg-[#96281b] text-white font-bold px-7 py-3 rounded-xl transition-all"
              >
                View Products <ArrowRight size={14} />
              </Link>
            </div>
          </div>

          {/* Navigation */}
          <div className="mt-10 flex justify-between items-center">
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 text-[#0f1f3d] hover:text-[#c0392b] font-medium transition-colors"
            >
              <ArrowLeft size={16} />
              Back to Blog
            </Link>
          </div>
        </div>
      </article>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="py-14 bg-white border-t border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <h2 className="text-2xl font-bold text-[#0f1f3d] mb-8">Related Articles</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedPosts.map((rel) => (
                <Link
                  key={rel.id}
                  href={`/blog/${rel.slug}`}
                  className="group bg-[#faf8f5] rounded-xl overflow-hidden border border-gray-100 hover:shadow-lg transition-all duration-300"
                >
                  <div className="relative h-40 overflow-hidden bg-gray-100">
                    <Image
                      src={rel.featuredImage || "/images/bricks-stacked.jpg"}
                      alt={rel.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <div className="p-4">
                    <span className="text-[#c0392b] text-xs font-semibold">{rel.category}</span>
                    <h3 className="font-bold text-[#0f1f3d] text-sm mt-1 leading-snug group-hover:text-[#c0392b] transition-colors line-clamp-2">
                      {rel.title}
                    </h3>
                    <div className="flex items-center gap-1 mt-2 text-gray-500 text-xs">
                      <Clock size={11} />
                      <span>{rel.readingTime} min read</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
