import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Clock, User, ArrowRight, Search } from "lucide-react";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const metadata: Metadata = {
  title: "Blog | BrickPoint — Construction Insights & Material Guides",
  description:
    "Explore BrickPoint's construction blog with guides on bricks, cement, steel, sand, and more. Expert insights for builders and homeowners.",
};

const blogCategories = [
  "All",
  "Bricks",
  "Construction Materials",
  "Home Construction",
  "Building Tips",
  "Construction Planning",
  "Material Buying Guides",
];

export default async function BlogPage() {
  let posts: typeof blogPosts.$inferSelect[] = [];
  try {
    posts = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.published, true))
      .orderBy(desc(blogPosts.createdAt));
  } catch (_e) {}

  const featured = posts.find((p) => p.featured);
  const rest = posts.filter((p) => !p.featured);

  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-14 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/bricks-stacked.jpg"
            alt="BrickPoint Blog"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/80" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Blog</span>
          </nav>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Construction Insights
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl">
            Guides, tips, and insights on construction materials, bricks, and building
            practices — from the BrickPoint team.
          </p>
        </div>
      </section>

      {/* Categories */}
      <div className="bg-white border-b border-gray-100 sticky top-[64px] z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex gap-2 overflow-x-auto py-3 scrollbar-hide">
            {blogCategories.map((cat) => (
              <span
                key={cat}
                className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium cursor-default ${
                  cat === "All"
                    ? "bg-[#0f1f3d] text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                {cat}
              </span>
            ))}
          </div>
        </div>
      </div>

      <section className="py-14 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          {posts.length > 0 ? (
            <>
              {/* Featured Post */}
              {featured && (
                <div className="mb-12">
                  <h2 className="text-lg font-bold text-[#0f1f3d] mb-5 flex items-center gap-2">
                    <span className="w-3 h-3 bg-[#c0392b] rounded-full" />
                    Featured Article
                  </h2>
                  <Link
                    href={`/blog/${featured.slug}`}
                    className="group grid grid-cols-1 lg:grid-cols-2 bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-2xl transition-all duration-300"
                  >
                    <div className="relative h-64 lg:h-auto overflow-hidden bg-gray-100">
                      <Image
                        src={featured.featuredImage || "/images/bricks-stacked.jpg"}
                        alt={featured.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-4 left-4">
                        <span className="bg-[#c0392b] text-white text-xs font-bold px-3 py-1.5 rounded-full">
                          {featured.category}
                        </span>
                      </div>
                    </div>
                    <div className="p-8 flex flex-col justify-center">
                      <h3 className="text-2xl font-bold text-[#0f1f3d] mb-4 leading-snug group-hover:text-[#c0392b] transition-colors">
                        {featured.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed mb-6 line-clamp-3">
                        {featured.excerpt}
                      </p>
                      <div className="flex items-center gap-5 text-sm text-gray-500 mb-5">
                        <div className="flex items-center gap-1.5">
                          <User size={14} />
                          <span>{featured.author}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock size={14} />
                          <span>{featured.readingTime} min read</span>
                        </div>
                      </div>
                      <div className="inline-flex items-center gap-2 text-[#c0392b] font-semibold text-sm group-hover:gap-3 transition-all">
                        Read Article <ArrowRight size={14} />
                      </div>
                    </div>
                  </Link>
                </div>
              )}

              {/* All Posts */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {rest.map((post) => (
                  <Link
                    key={post.id}
                    href={`/blog/${post.slug}`}
                    className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300"
                  >
                    <div className="relative h-48 overflow-hidden bg-gray-100">
                      <Image
                        src={post.featuredImage || "/images/bricks-stacked.jpg"}
                        alt={post.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-3 left-3">
                        <span className="bg-[#c0392b] text-white text-xs font-semibold px-3 py-1 rounded-full">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    <div className="p-5">
                      <h3 className="font-bold text-[#0f1f3d] text-base leading-snug mb-3 group-hover:text-[#c0392b] transition-colors line-clamp-2">
                        {post.title}
                      </h3>
                      <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-2">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <User size={11} />
                          <span>{post.author}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock size={11} />
                          <span>{post.readingTime} min</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-20">
              <Search size={48} className="text-gray-300 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-[#0f1f3d] mb-3">Blog Coming Soon</h2>
              <p className="text-gray-600 max-w-md mx-auto">
                We are preparing construction guides and material insights. Check back soon.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter / Follow section */}
      <section className="py-14 bg-[#0f1f3d]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Stay Updated with BrickPoint
          </h2>
          <p className="text-gray-300 text-lg mb-8">
            Follow us on social media and join our WhatsApp channel for construction
            tips, product updates, and company news.
          </p>
          <a
            href="https://whatsapp.com/channel/0029VbDHPm45a23w88ADzK32"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold px-8 py-4 rounded-xl transition-all duration-200"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Join Our WhatsApp Channel
          </a>
        </div>
      </section>
    </>
  );
}
