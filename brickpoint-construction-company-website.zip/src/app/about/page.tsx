import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CheckCircle, Users, Building2, Target } from "lucide-react";

export const metadata: Metadata = {
  title: "About Us | BrickPoint — SS7 Bricks & Construction Materials",
  description:
    "Learn about BrickPoint, representing Masha Allah Bricks Company and Fine Bricks Company. Trusted supplier of SS7 bricks and construction materials.",
};

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-16 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/hero-bricks.jpg"
            alt="About BrickPoint"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/80" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-3xl">
            <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6">
              <Link href="/" className="hover:text-white transition-colors">Home</Link>
              <span>/</span>
              <span className="text-white">About Us</span>
            </nav>
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              About BrickPoint
            </p>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-5">
              Your Trusted Partner in
              <br />
              <span className="text-[#c0392b]">Construction Materials</span>
            </h1>
            <p className="text-gray-300 text-lg leading-relaxed">
              BrickPoint represents Masha Allah Bricks Company and Fine Bricks Company —
              supplying SS7 bricks and essential construction materials to builders,
              contractors, and developers.
            </p>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
                Our Story
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-6 leading-tight">
                Building Relationships,
                <br />One Brick at a Time
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  BrickPoint is the digital face of two established brick manufacturing
                  companies in Pakistan — <strong className="text-[#0f1f3d]">Masha Allah Bricks Company</strong>{" "}
                  and <strong className="text-[#0f1f3d]">Fine Bricks Company</strong>. Together,
                  they operate multiple brick manufacturing facilities (bhattas) producing
                  quality bricks for the construction industry.
                </p>
                <p>
                  Our primary product is the <strong className="text-[#0f1f3d]">SS7 branded brick</strong> —
                  a recognized name among builders, contractors, and construction companies
                  looking for consistent quality and dependable supply.
                </p>
                <p>
                  Through BrickPoint, we bring together our manufacturing expertise and customer
                  service under one brand, making it easier for builders, developers, architects,
                  and homeowners to source quality construction materials efficiently.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  "SS7 Branded Bricks",
                  "Multiple Manufacturing Locations",
                  "Bulk Order Capability",
                  "WhatsApp Ordering",
                  "Direct Manufacturer Access",
                  "Wide Construction Material Range",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-gray-700 text-sm">
                    <CheckCircle size={16} className="text-[#c0392b] flex-shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <Image
                  src="/images/about-team.jpg"
                  alt="BrickPoint Team"
                  width={600}
                  height={450}
                  className="w-full h-80 object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-[#c0392b] text-white rounded-xl p-5 shadow-xl hidden sm:block">
                <div className="text-3xl font-black">SS7</div>
                <div className="text-xs uppercase tracking-widest mt-1">Brick Brand</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Companies Section */}
      <section className="py-16 md:py-20 bg-[#f0ebe3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              Our Companies
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-4">
              Under the BrickPoint Brand
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              BrickPoint represents two manufacturing companies operating brick production
              facilities across multiple locations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-[#c0392b]/10 rounded-xl flex items-center justify-center mb-5">
                <Building2 size={28} className="text-[#c0392b]" />
              </div>
              <h3 className="text-2xl font-bold text-[#0f1f3d] mb-3">
                Masha Allah Bricks Company
              </h3>
              <p className="text-gray-600 leading-relaxed mb-5">
                Masha Allah Bricks Company operates two brick manufacturing facilities
                (bhattas), producing quality SS7 branded bricks and other construction
                bricks for the local market.
              </p>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#c0392b] rounded-full" />
                  <span>Bhatta 1 — Ram Thaman</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#c0392b] rounded-full" />
                  <span>Bhatta 3 — Active Location</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-[#0f1f3d]/10 rounded-xl flex items-center justify-center mb-5">
                <Building2 size={28} className="text-[#0f1f3d]" />
              </div>
              <h3 className="text-2xl font-bold text-[#0f1f3d] mb-3">
                Fine Bricks Company
              </h3>
              <p className="text-gray-600 leading-relaxed mb-5">
                Fine Bricks Company operates a brick manufacturing facility (Bhatta 2)
                producing quality bricks under the SS7 brand and serving construction
                projects across the region.
              </p>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#0f1f3d] rounded-full" />
                  <span>Bhatta 2 — Raja Jang</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative order-2 lg:order-1">
              <Image
                src="/images/brick-factory.jpg"
                alt="Brick manufacturing"
                width={600}
                height={400}
                className="w-full h-72 object-cover rounded-2xl shadow-xl"
              />
            </div>
            <div className="order-1 lg:order-2">
              <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
                Who We Serve
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-6">
                Built for Every Builder
              </h2>
              <p className="text-gray-600 leading-relaxed mb-6">
                BrickPoint serves a wide range of customers from large-scale construction
                companies to individual homeowners starting their first project.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { icon: <Target size={18} />, label: "Builders & Contractors" },
                  { icon: <Building2 size={18} />, label: "Developers" },
                  { icon: <Users size={18} />, label: "Construction Companies" },
                  { icon: <CheckCircle size={18} />, label: "Homeowners" },
                  { icon: <Target size={18} />, label: "Architects" },
                  { icon: <Building2 size={18} />, label: "Project Managers" },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center gap-3 bg-white border border-gray-100 rounded-xl px-4 py-3 shadow-sm"
                  >
                    <div className="text-[#c0392b]">{item.icon}</div>
                    <span className="text-[#0f1f3d] font-medium text-sm">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="py-16 md:py-20 bg-[#0f1f3d]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              Our Leadership
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Meet the Team
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row justify-center gap-6 max-w-2xl mx-auto">
            {[
              {
                name: "Syed Iftikhar Haider",
                title: "Chief Executive Officer",
                desc: "Leading BrickPoint with a vision for quality construction materials and exceptional customer service.",
              },
              {
                name: "Qasim Iqbal",
                title: "Sales Manager",
                desc: "Managing customer relationships and ensuring timely fulfillment of orders for all product categories.",
              },
            ].map((person) => (
              <div
                key={person.name}
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 transition-colors"
              >
                <div className="w-20 h-20 bg-[#c0392b]/20 border-2 border-[#c0392b] rounded-full flex items-center justify-center mx-auto mb-5">
                  <span className="text-[#c0392b] text-3xl font-bold">
                    {person.name.charAt(0)}
                  </span>
                </div>
                <h3 className="text-white font-bold text-xl mb-1">{person.name}</h3>
                <p className="text-[#c0392b] text-sm font-medium uppercase tracking-wide mb-4">
                  {person.title}
                </p>
                <p className="text-gray-400 text-sm leading-relaxed">{person.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-14 bg-[#c0392b]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Order Construction Materials?
          </h2>
          <p className="text-red-100 text-lg mb-8">
            Contact our team on WhatsApp for product pricing, availability, and delivery.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/923152850818"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-white text-[#c0392b] hover:bg-gray-100 font-bold px-8 py-4 rounded-xl transition-all duration-200"
            >
              Order on WhatsApp
            </a>
            <Link
              href="/products"
              className="inline-flex items-center justify-center gap-2 border-2 border-white text-white hover:bg-white hover:text-[#c0392b] font-bold px-8 py-4 rounded-xl transition-all duration-200"
            >
              Explore Products <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
