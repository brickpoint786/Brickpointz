import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CheckCircle, Star, Phone, HelpCircle } from "lucide-react";
import WhatsAppButton from "@/components/WhatsAppButton";

export const metadata: Metadata = {
  title: "SS7 Bricks | BrickPoint — Premium Quality Construction Bricks",
  description:
    "Discover SS7 bricks from BrickPoint — a trusted choice for construction projects through Masha Allah Bricks Company and Fine Bricks Company. Order on WhatsApp.",
};

const faqs = [
  {
    q: "What are SS7 bricks?",
    a: "SS7 bricks are a branded variety of red clay construction bricks available through BrickPoint via Masha Allah Bricks Company and Fine Bricks Company. They are recognized for consistent quality and reliable availability.",
  },
  {
    q: "Where can I order SS7 bricks?",
    a: "You can order SS7 bricks directly through WhatsApp at 03152850818, by calling the same number, or by visiting our factory locations at Ram Thaman (Bhatta 1 & 3) and Raja Jang (Bhatta 2).",
  },
  {
    q: "Do you supply SS7 bricks in bulk?",
    a: "Yes, we supply SS7 bricks in bulk quantities for residential, commercial, and development projects. Contact us on WhatsApp with your quantity requirements for a quotation.",
  },
  {
    q: "What is the price of SS7 bricks?",
    a: "Brick prices can vary based on quantity, location, and market conditions. Contact us on WhatsApp or by phone for the latest pricing and availability.",
  },
  {
    q: "Do you deliver to construction sites?",
    a: "Please contact us directly on WhatsApp or by phone to discuss delivery arrangements and logistics for your project location.",
  },
  {
    q: "What other products does BrickPoint supply?",
    a: "In addition to SS7 bricks, BrickPoint supplies a wide range of construction materials including cement, steel, sand, crush, electric pipes, plumbing fittings, construction chemicals, paints, lights, and more.",
  },
];

export default function SS7BricksPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] min-h-[70vh] flex items-center relative overflow-hidden py-16">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/bricks-stacked.jpg"
            alt="SS7 Bricks"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f1f3d] via-[#0f1f3d]/90 to-[#0f1f3d]/50" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 w-full">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-8 flex-wrap">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">SS7 Bricks</span>
          </nav>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-[#c0392b] text-white text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wider mb-6">
                <Star size={12} fill="white" />
                Featured Brick Brand — BrickPoint
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                SS7 Bricks
                <br />
                <span className="text-[#c0392b]">Trusted Quality</span>
                <br />
                for Construction
              </h1>
              <p className="text-gray-300 text-lg leading-relaxed mb-8">
                Discover SS7 bricks from BrickPoint — a recognized choice for construction
                projects where quality, consistency, and dependable supply matter.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <WhatsAppButton
                  productName="SS7 Bricks"
                  category="Bricks"
                  price="Price on Request"
                  variant="primary"
                />
                <Link
                  href="/products/bricks"
                  className="inline-flex items-center justify-center gap-2 border-2 border-white text-white hover:bg-white hover:text-[#0f1f3d] font-semibold px-7 py-3 rounded-lg transition-all duration-200 text-sm"
                >
                  View All Bricks <ArrowRight size={14} />
                </Link>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  "SS7 Branded Quality",
                  "Consistent Supply",
                  "Bulk Orders Welcome",
                  "Multiple Locations",
                ].map((feat) => (
                  <div key={feat} className="flex items-center gap-2 text-gray-300 text-sm">
                    <CheckCircle size={14} className="text-[#c0392b] flex-shrink-0" />
                    {feat}
                  </div>
                ))}
              </div>
            </div>

            {/* SS7 Visual */}
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="/images/ss7-brick.jpg"
                  alt="SS7 Brick — Premium Quality"
                  width={600}
                  height={500}
                  className="w-full h-80 lg:h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f1f3d]/50 to-transparent" />
              </div>
              <div className="absolute -top-5 -right-5 bg-[#c0392b] text-white rounded-2xl p-5 shadow-2xl">
                <div className="text-center">
                  <div className="text-3xl font-black">SS7</div>
                  <div className="text-[10px] uppercase tracking-widest mt-0.5">Bricks</div>
                </div>
              </div>
              <div className="absolute -bottom-5 -left-5 bg-white rounded-xl p-4 shadow-xl hidden sm:block">
                <div className="flex items-center gap-3">
                  <Star size={20} className="text-[#c0392b]" fill="#c0392b" />
                  <div>
                    <div className="text-[#0f1f3d] font-bold text-sm">Premium Brand</div>
                    <div className="text-gray-500 text-xs">via BrickPoint</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About SS7 */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
                About SS7 Bricks
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-6">
                A Trusted Choice for
                <br />Strong Construction
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  SS7 bricks are available through BrickPoint, representing two established brick
                  manufacturing companies in Pakistan —{" "}
                  <strong className="text-[#0f1f3d]">Masha Allah Bricks Company</strong> and{" "}
                  <strong className="text-[#0f1f3d]">Fine Bricks Company</strong>.
                </p>
                <p>
                  The SS7 mark represents a commitment to consistent dimensions, quality clay,
                  and reliable supply — making them a preferred choice among builders, contractors,
                  and construction companies who need dependable materials.
                </p>
                <p>
                  Whether you are building a residential home, commercial structure, boundary wall,
                  or any other masonry project, SS7 bricks from BrickPoint offer consistent quality
                  and dependable availability.
                </p>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/images/brick-factory.jpg"
                alt="Brick manufacturing"
                width={600}
                height={400}
                className="w-full h-72 object-cover rounded-2xl shadow-xl"
              />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-[#0f1f3d]/30 to-transparent" />
            </div>
          </div>
        </div>
      </section>

      {/* Product Details */}
      <section className="py-16 md:py-20 bg-[#f0ebe3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-4">
              SS7 Brick Details
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Everything you need to know about ordering SS7 bricks from BrickPoint.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Product card */}
            <div className="lg:col-span-2 bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100">
              <div className="relative h-64">
                <Image
                  src="/images/ss7-brick.jpg"
                  alt="SS7 Bricks"
                  fill
                  className="object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-[#c0392b] text-white text-sm font-bold px-3 py-1.5 rounded-lg uppercase tracking-wide flex items-center gap-1.5">
                    <Star size={12} fill="white" />
                    SS7 Brand
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-[#0f1f3d] mb-4">SS7 Bricks — Standard</h3>
                <div className="bg-[#f0ebe3] rounded-xl p-4 mb-5">
                  <p className="text-[#0f1f3d] font-bold text-lg">Price on Request</p>
                  <p className="text-gray-500 text-sm mt-0.5">
                    Contact us for current market pricing | Per 1,000 Bricks
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3 mb-5">
                  {[
                    "SS7 Branded Quality",
                    "Consistent Dimensions",
                    "Suitable for Load-Bearing Walls",
                    "Available in Bulk Orders",
                    "Reliable Supply Chain",
                    "Multiple Factory Locations",
                  ].map((feat) => (
                    <div key={feat} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle size={14} className="text-[#c0392b] flex-shrink-0" />
                      {feat}
                    </div>
                  ))}
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <WhatsAppButton
                    productName="SS7 Bricks"
                    category="Bricks"
                    price="Price on Request"
                    variant="primary"
                    className="flex-1 justify-center"
                  />
                  <a
                    href="tel:03152850818"
                    className="flex-1 inline-flex items-center justify-center gap-2 bg-[#0f1f3d] hover:bg-[#1a3260] text-white font-semibold py-2.5 rounded-lg transition-all text-sm"
                  >
                    <Phone size={16} />
                    Call to Order
                  </a>
                </div>
              </div>
            </div>

            {/* Side Info */}
            <div className="space-y-5">
              {/* Specs */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#0f1f3d] mb-4 text-sm uppercase tracking-wide">
                  Product Information
                </h3>
                <div className="space-y-3">
                  {[
                    { label: "Brand", value: "SS7" },
                    { label: "Type", value: "Standard Clay Brick" },
                    { label: "Product Code", value: "SS7-STD" },
                    { label: "Supplier", value: "BrickPoint" },
                    { label: "Companies", value: "Masha Allah / Fine Bricks Co." },
                    { label: "Availability", value: "Available" },
                    { label: "Order Unit", value: "Per 1,000 Bricks" },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between text-sm">
                      <span className="text-gray-500">{item.label}</span>
                      <span className="text-[#0f1f3d] font-medium text-right">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact */}
              <div className="bg-[#0f1f3d] rounded-2xl p-6">
                <h3 className="font-bold text-white mb-4 text-sm uppercase tracking-wide">
                  Quick Order
                </h3>
                <div className="space-y-3">
                  <a
                    href="https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20am%20interested%20in%20SS7%20Bricks.%20Please%20share%20the%20latest%20price%20and%20availability."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-semibold py-3 rounded-xl transition-colors w-full text-sm"
                  >
                    Order on WhatsApp
                  </a>
                  <a
                    href="tel:03152850818"
                    className="flex items-center justify-center gap-2 border border-white/20 hover:border-white/40 text-white font-semibold py-3 rounded-xl transition-colors w-full text-sm"
                  >
                    <Phone size={15} />
                    03152850818
                  </a>
                </div>
                <p className="text-gray-400 text-xs mt-4 text-center">
                  Sales Manager: Qasim Iqbal
                </p>
              </div>

              {/* Locations */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 className="font-bold text-[#0f1f3d] mb-4 text-sm uppercase tracking-wide">
                  Factory Locations
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="text-gray-600">
                    <span className="font-medium text-[#0f1f3d]">Bhatta 1 & 3</span> — Ram Thaman
                    <br />
                    <span className="text-xs text-gray-400">Masha Allah Bricks Company</span>
                  </div>
                  <div className="text-gray-600">
                    <span className="font-medium text-[#0f1f3d]">Bhatta 2</span> — Raja Jang
                    <br />
                    <span className="text-xs text-gray-400">Fine Bricks Company</span>
                  </div>
                </div>
                <Link
                  href="/locations"
                  className="text-[#c0392b] text-xs font-medium hover:text-[#96281b] mt-3 inline-flex items-center gap-1"
                >
                  View All Locations <ArrowRight size={10} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="text-2xl font-bold text-[#0f1f3d] mb-6">SS7 Bricks Gallery</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              "/images/ss7-brick.jpg",
              "/images/bricks-stacked.jpg",
              "/images/brick-factory.jpg",
              "/images/construction-project.jpg",
            ].map((img, i) => (
              <div key={i} className="relative rounded-xl overflow-hidden shadow-sm aspect-square">
                <Image
                  src={img}
                  alt={`SS7 Bricks ${i + 1}`}
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-[#0f1f3d]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-white mb-3">
              SS7 Brick Applications
            </h2>
            <p className="text-gray-400">Suitable for a wide range of construction projects</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              "Residential Homes",
              "Commercial Buildings",
              "Boundary Walls",
              "Villa Construction",
              "Housing Projects",
              "General Masonry",
            ].map((app) => (
              <div
                key={app}
                className="bg-white/5 border border-white/10 rounded-xl p-4 text-center hover:bg-white/10 transition-colors"
              >
                <div className="text-2xl mb-2">🧱</div>
                <p className="text-white text-xs font-medium leading-tight">{app}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-[#0f1f3d] mb-3">
              Frequently Asked Questions
            </h2>
            <p className="text-gray-600">Common questions about SS7 bricks and ordering</p>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm"
              >
                <div className="flex items-start gap-3">
                  <HelpCircle size={18} className="text-[#c0392b] flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-[#0f1f3d] mb-2">{faq.q}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{faq.a}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#c0392b]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Order SS7 Bricks Today
          </h2>
          <p className="text-red-100 text-lg mb-8">
            Contact BrickPoint on WhatsApp for pricing, availability, and bulk orders.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20would%20like%20to%20order%20SS7%20Bricks.%20Please%20share%20the%20latest%20price%20and%20availability."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-white text-[#c0392b] hover:bg-gray-100 font-bold px-8 py-4 rounded-xl transition-all duration-200 text-base"
            >
              Order on WhatsApp
            </a>
            <a
              href="tel:03152850818"
              className="inline-flex items-center justify-center gap-2 border-2 border-white text-white hover:bg-white hover:text-[#c0392b] font-bold px-8 py-4 rounded-xl transition-all duration-200 text-base"
            >
              <Phone size={18} />
              Call 03152850818
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
