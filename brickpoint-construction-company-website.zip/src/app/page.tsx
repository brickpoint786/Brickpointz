import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Phone, Shield, Truck, Star, Package, MapPin, CheckCircle } from "lucide-react";
import { PRODUCT_CATEGORIES } from "@/lib/data";

const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

export default function HomePage() {
  return (
    <>
      {/* ===== HERO SECTION ===== */}
      <section className="relative bg-[#0f1f3d] min-h-[90vh] flex items-center overflow-hidden">
        {/* Background image overlay */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/hero-bricks.jpg"
            alt="BrickPoint construction bricks"
            fill
            className="object-cover opacity-25"
            priority
          />
        </div>
        {/* Gradient overlay */}
        <div className="absolute inset-0 z-0 bg-gradient-to-r from-[#0f1f3d] via-[#0f1f3d]/90 to-[#0f1f3d]/50" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-16 md:py-20 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Hero Text */}
            <div>
              {/* Trust badge */}
              <div className="inline-flex items-center gap-2 bg-[#c0392b]/20 border border-[#c0392b]/40 text-[#f5a8a0] rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-widest mb-6">
                <span className="w-2 h-2 bg-[#c0392b] rounded-full animate-pulse" />
                SS7 Bricks Now Available
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                Building Strong
                <br />
                <span className="text-[#c0392b]">Foundations</span> with
                <br />
                Quality Materials
              </h1>

              <p className="text-gray-300 text-lg leading-relaxed mb-8 max-w-xl">
                From SS7 bricks to essential construction materials, BrickPoint helps
                builders, contractors, and homeowners build with confidence.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <Link
                  href="/products"
                  className="inline-flex items-center justify-center gap-2 bg-[#c0392b] hover:bg-[#96281b] text-white font-semibold px-7 py-3.5 rounded-lg transition-all duration-200 text-sm tracking-wide"
                >
                  Explore Products
                  <ArrowRight size={16} />
                </Link>
                <a
                  href="https://wa.me/923152850818"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-semibold px-7 py-3.5 rounded-lg transition-all duration-200 text-sm tracking-wide"
                >
                  <WhatsAppIcon />
                  Order on WhatsApp
                </a>
              </div>

              {/* Trust line */}
              <div className="flex items-center gap-2 text-gray-400 text-sm flex-wrap">
                <CheckCircle size={14} className="text-[#c0392b]" />
                <span>Quality Bricks</span>
                <span className="text-gray-600">•</span>
                <CheckCircle size={14} className="text-[#c0392b]" />
                <span>Reliable Supply</span>
                <span className="text-gray-600">•</span>
                <CheckCircle size={14} className="text-[#c0392b]" />
                <span>Construction Materials</span>
              </div>
            </div>

            {/* Hero Right — SS7 Feature + Video Area */}
            <div className="relative flex flex-col gap-4">
              {/* SS7 Product Showcase */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-[#1a3260] border border-white/10">
                <div className="relative h-64 sm:h-72 lg:h-80">
                  <Image
                    src="/images/ss7-brick.jpg"
                    alt="SS7 Bricks — Premium Quality"
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f1f3d]/80 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <div className="inline-flex items-center gap-1.5 bg-[#c0392b] text-white text-xs font-bold px-3 py-1 rounded uppercase tracking-wider mb-2">
                      <Star size={10} fill="white" />
                      Featured Brick Brand
                    </div>
                    <h3 className="text-white font-bold text-xl">SS7 Bricks</h3>
                    <p className="text-gray-300 text-sm">Premium quality for strong construction</p>
                  </div>
                </div>
              </div>

              {/* Video placeholder area */}
              <div className="relative rounded-xl overflow-hidden bg-[#1a3260] border border-white/10 shadow-xl">
                <div className="relative h-44 sm:h-52 flex items-center justify-center">
                  <video
                    className="w-full h-full object-cover"
                    autoPlay
                    muted
                    loop
                    playsInline
                    poster="/images/brick-factory.jpg"
                  >
                    {/* Replace /videos/brickpoint-product.mp4 with your video file */}
                    <source src="/videos/brickpoint-product.mp4" type="video/mp4" />
                    {/* Fallback if no video */}
                    <Image
                      src="/images/brick-factory.jpg"
                      alt="Brick manufacturing"
                      fill
                      className="object-cover"
                    />
                  </video>
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f1f3d]/60 to-transparent" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center">
                      <div className="w-0 h-0 border-t-4 border-b-4 border-l-8 border-transparent border-l-white ml-1" />
                    </div>
                  </div>
                  <div className="absolute bottom-3 left-3">
                    <span className="text-white text-xs bg-black/40 backdrop-blur-sm px-2 py-1 rounded">
                      SS7 Brick Manufacturing
                    </span>
                  </div>
                </div>
              </div>

              {/* Contact card */}
              <div className="bg-[#1a3260] border border-white/10 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-xs">Speak to Sales</p>
                  <p className="text-white font-bold text-lg">03152850818</p>
                  <p className="text-gray-400 text-xs">Qasim Iqbal — Sales Manager</p>
                </div>
                <div className="flex gap-2">
                  <a
                    href="tel:03152850818"
                    className="bg-[#0f1f3d] hover:bg-white/10 border border-white/20 text-white p-2.5 rounded-lg transition-colors"
                  >
                    <Phone size={16} />
                  </a>
                  <a
                    href="https://wa.me/923152850818"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#25D366] hover:bg-[#1da855] text-white p-2.5 rounded-lg transition-colors"
                  >
                    <WhatsAppIcon />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom wave */}
        <div className="absolute bottom-0 left-0 right-0 z-10">
          <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" className="w-full h-10 sm:h-14">
            <path d="M0 60V30C240 0 480 60 720 30C960 0 1200 60 1440 30V60H0Z" fill="#faf8f5" />
          </svg>
        </div>
      </section>

      {/* ===== BRAND TRUST SECTION ===== */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              Who We Are
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-4">
              Quality Materials. Stronger Foundations.
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto leading-relaxed">
              BrickPoint represents{" "}
              <strong className="text-[#0f1f3d]">Masha Allah Bricks Company</strong> and{" "}
              <strong className="text-[#0f1f3d]">Fine Bricks Company</strong> — supplying
              SS7 branded bricks and construction materials to builders, contractors,
              developers, and homeowners.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Shield size={28} className="text-[#c0392b]" />,
                title: "Quality Focus",
                desc: "We source and supply materials that meet consistent quality standards, starting with our signature SS7 branded bricks.",
              },
              {
                icon: <Truck size={28} className="text-[#c0392b]" />,
                title: "Reliable Supply",
                desc: "Dependable material availability and delivery coordination for uninterrupted construction progress.",
              },
              {
                icon: <Package size={28} className="text-[#c0392b]" />,
                title: "Construction Expertise",
                desc: "Deep knowledge of construction materials allows us to help you find the right product for every application.",
              },
              {
                icon: <Phone size={28} className="text-[#c0392b]" />,
                title: "Customer Support",
                desc: "Direct WhatsApp and phone access to our team. We are available to answer your inquiries promptly.",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-7 border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group"
              >
                <div className="w-14 h-14 bg-[#faf8f5] group-hover:bg-[#c0392b]/10 rounded-xl flex items-center justify-center mb-5 transition-colors">
                  {item.icon}
                </div>
                <h3 className="font-bold text-[#0f1f3d] text-lg mb-3">{item.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Company names */}
          <div className="mt-12 flex flex-col sm:flex-row gap-4 justify-center items-center">
            <div className="flex items-center gap-3 bg-white border border-gray-200 rounded-xl px-6 py-4 shadow-sm">
              <div className="w-3 h-3 bg-[#c0392b] rounded-full" />
              <span className="text-[#0f1f3d] font-semibold">Masha Allah Bricks Company</span>
            </div>
            <div className="flex items-center gap-3 bg-white border border-gray-200 rounded-xl px-6 py-4 shadow-sm">
              <div className="w-3 h-3 bg-[#0f1f3d] rounded-full" />
              <span className="text-[#0f1f3d] font-semibold">Fine Bricks Company</span>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FEATURED SS7 BRICKS SECTION ===== */}
      <section className="py-16 md:py-24 bg-[#0f1f3d] relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 30px, rgba(255,255,255,0.1) 30px, rgba(255,255,255,0.1) 31px), repeating-linear-gradient(90deg, transparent, transparent 60px, rgba(255,255,255,0.1) 60px, rgba(255,255,255,0.1) 61px)",
          }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* SS7 Image */}
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="/images/ss7-brick.jpg"
                  alt="SS7 Bricks - Premium Quality"
                  width={600}
                  height={500}
                  className="w-full h-80 sm:h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f1f3d]/60 to-transparent" />
              </div>
              {/* Badge */}
              <div className="absolute -top-4 -right-4 bg-[#c0392b] text-white rounded-2xl p-4 shadow-xl">
                <div className="text-center">
                  <div className="text-2xl font-black">SS7</div>
                  <div className="text-[10px] uppercase tracking-widest">Bricks</div>
                </div>
              </div>
              {/* Floating card */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl p-4 shadow-xl border border-gray-100 hidden sm:block">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#c0392b]/10 rounded-lg flex items-center justify-center">
                    <Star size={20} className="text-[#c0392b]" fill="#c0392b" />
                  </div>
                  <div>
                    <div className="text-[#0f1f3d] font-bold text-sm">Featured Brick Brand</div>
                    <div className="text-gray-500 text-xs">Reliable Quality Supply</div>
                  </div>
                </div>
              </div>
            </div>

            {/* SS7 Content */}
            <div>
              <div className="inline-flex items-center gap-2 bg-[#c0392b] text-white text-xs font-bold px-3 py-1.5 rounded uppercase tracking-wider mb-5">
                <Star size={12} fill="white" />
                Featured Brick Brand
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-white leading-tight mb-5">
                SS7 Bricks — Built for
                <br />
                <span className="text-[#c0392b]">Stronger Foundations</span>
              </h2>
              <p className="text-gray-300 text-lg leading-relaxed mb-6">
                Discover SS7 bricks from BrickPoint — a trusted choice for construction
                projects where quality, consistency, and dependable supply matter.
              </p>
              <p className="text-gray-400 leading-relaxed mb-8">
                Through{" "}
                <span className="text-white font-medium">Masha Allah Bricks Company</span>{" "}
                and{" "}
                <span className="text-white font-medium">Fine Bricks Company</span>,
                BrickPoint ensures you receive genuine SS7 bricks with reliable availability
                and professional service for every project size.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {[
                  "SS7 Branded Quality",
                  "Consistent Dimensions",
                  "Reliable Bulk Supply",
                  "Suitable for All Construction",
                ].map((feat) => (
                  <div key={feat} className="flex items-center gap-2 text-gray-300 text-sm">
                    <CheckCircle size={16} className="text-[#c0392b] flex-shrink-0" />
                    {feat}
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/ss7-bricks"
                  className="inline-flex items-center justify-center gap-2 bg-[#c0392b] hover:bg-[#96281b] text-white font-semibold px-7 py-3.5 rounded-lg transition-all duration-200"
                >
                  View SS7 Bricks
                  <ArrowRight size={16} />
                </Link>
                <a
                  href="https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20am%20interested%20in%20SS7%20Bricks.%20Please%20share%20availability%20and%20pricing."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 border-2 border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white font-semibold px-7 py-3.5 rounded-lg transition-all duration-200"
                >
                  <WhatsAppIcon />
                  Order on WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== PRODUCTS SECTION ===== */}
      <section className="py-16 md:py-24 bg-[#f0ebe3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-3">
              Our Product Range
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-4">
              Explore Our Construction Materials
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              From SS7 bricks to complete construction solutions — everything your project needs, in one place.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {PRODUCT_CATEGORIES.map((cat) => (
              <Link
                key={cat.slug}
                href={`/products/${cat.slug}`}
                className="group bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
              >
                <div className="relative h-32 overflow-hidden bg-gray-100">
                  <Image
                    src={cat.image}
                    alt={cat.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  {cat.badge && (
                    <div className="absolute top-2 left-2">
                      <span className="bg-[#c0392b] text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wide">
                        {cat.badge}
                      </span>
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2 right-2">
                    <span className="text-2xl">{cat.icon}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-[#0f1f3d] text-sm group-hover:text-[#c0392b] transition-colors leading-tight">
                    {cat.name}
                  </h3>
                  <p className="text-gray-500 text-xs mt-1 line-clamp-2 leading-relaxed hidden sm:block">
                    {cat.description}
                  </p>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-10">
            <Link
              href="/products"
              className="inline-flex items-center gap-2 bg-[#0f1f3d] hover:bg-[#1a3260] text-white font-semibold px-8 py-3.5 rounded-lg transition-all duration-200"
            >
              View All Products
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* ===== PROJECTS PREVIEW ===== */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-2">
                Our Work
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d]">
                Featured Projects
              </h2>
            </div>
            <Link
              href="/projects"
              className="inline-flex items-center gap-2 text-[#c0392b] hover:text-[#96281b] font-medium text-sm transition-colors"
            >
              View All Projects <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Modern Residential Villa — DHA Lahore",
                category: "Residential",
                location: "DHA Lahore",
                image: "/images/construction-project.jpg",
              },
              {
                title: "Commercial Development — Bahria Town",
                category: "Commercial",
                location: "Bahria Town Lahore",
                image: "/images/hero-bricks.jpg",
              },
              {
                title: "Premium Brickwork — Lake City",
                category: "Brickwork",
                location: "Lake City Lahore",
                image: "/images/bricks-stacked.jpg",
              },
            ].map((proj, i) => (
              <div
                key={i}
                className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300"
              >
                <div className="relative h-52 overflow-hidden">
                  <Image
                    src={proj.image}
                    alt={proj.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f1f3d]/60 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#c0392b] text-white text-xs font-semibold px-3 py-1 rounded-full">
                      {proj.category}
                    </span>
                  </div>
                  <div className="absolute top-3 right-3">
                    <span className="bg-white/90 text-gray-600 text-[10px] font-medium px-2 py-1 rounded-full">
                      Illustrative
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-[#0f1f3d] text-base leading-snug mb-2">
                    {proj.title}
                  </h3>
                  <div className="flex items-center gap-1 text-gray-500 text-xs">
                    <MapPin size={12} />
                    {proj.location}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== LOCATIONS STRIP ===== */}
      <section className="py-12 bg-[#0f1f3d]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-white font-bold text-xl mb-1">Find Our Locations</h3>
              <p className="text-gray-400 text-sm">
                Visit our brick factories or contact us for delivery to your site.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              <Link
                href="/locations"
                className="inline-flex items-center justify-center gap-2 bg-white text-[#0f1f3d] hover:bg-gray-100 font-semibold px-6 py-3 rounded-lg transition-all duration-200 text-sm"
              >
                <MapPin size={15} />
                View All Locations
              </Link>
              <a
                href="https://wa.me/923152850818"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-semibold px-6 py-3 rounded-lg transition-all duration-200 text-sm"
              >
                <WhatsAppIcon />
                Contact on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ===== BLOG PREVIEW ===== */}
      <section className="py-16 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-[#c0392b] text-sm font-semibold uppercase tracking-widest mb-2">
                Knowledge Base
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-[#0f1f3d]">
                Construction Insights
              </h2>
            </div>
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 text-[#c0392b] hover:text-[#96281b] font-medium text-sm transition-colors"
            >
              View All Posts <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "How to Choose Quality Bricks for Your Home",
                category: "Bricks",
                readTime: "5 min read",
                image: "/images/bricks-stacked.jpg",
                slug: "how-to-choose-quality-bricks",
              },
              {
                title: "SS7 Bricks and Their Role in Construction",
                category: "Bricks",
                readTime: "4 min read",
                image: "/images/ss7-brick.jpg",
                slug: "ss7-bricks-role-in-construction",
              },
              {
                title: "Essential Construction Materials for Building a House",
                category: "Construction Materials",
                readTime: "6 min read",
                image: "/images/construction-project.jpg",
                slug: "essential-construction-materials-pakistan",
              },
            ].map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300"
              >
                <div className="relative h-44 overflow-hidden">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#c0392b] text-white text-xs font-semibold px-3 py-1 rounded-full">
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-[#0f1f3d] text-base leading-snug mb-3 group-hover:text-[#c0392b] transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>BrickPoint Team</span>
                    <span>{post.readTime}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CTA SECTION ===== */}
      <section className="py-16 bg-[#c0392b] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,0.3) 20px, rgba(255,255,255,0.3) 21px)",
          }} />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Start Your Project?
          </h2>
          <p className="text-red-100 text-lg mb-8 max-w-xl mx-auto">
            Contact BrickPoint today for SS7 bricks and quality construction materials.
            Our sales team is ready to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/923152850818"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-white text-[#c0392b] hover:bg-gray-100 font-bold px-8 py-4 rounded-xl transition-all duration-200 text-base"
            >
              <WhatsAppIcon />
              Order on WhatsApp
            </a>
            <a
              href="tel:03152850818"
              className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-white text-white hover:bg-white hover:text-[#c0392b] font-bold px-8 py-4 rounded-xl transition-all duration-200 text-base"
            >
              <Phone size={18} />
              Call 03152850818
            </a>
          </div>
          <p className="text-red-200 text-sm mt-6">
            CEO: Syed Iftikhar Haider &nbsp;|&nbsp; Sales Manager: Qasim Iqbal
          </p>
        </div>
      </section>
    </>
  );
}
