import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

export const metadata: Metadata = {
  title: "BrickPoint | SS7 Bricks & Construction Materials in Lahore",
  description:
    "BrickPoint provides SS7 bricks and a wide range of construction materials through Masha Allah Bricks Company and Fine Bricks Company. Explore products, locations, and WhatsApp ordering.",
  keywords:
    "BrickPoint, SS7 bricks, construction materials, Lahore bricks, brick supplier, Masha Allah Bricks, Fine Bricks Company, cement, steel, construction supply",
  openGraph: {
    title: "BrickPoint | SS7 Bricks & Construction Materials",
    description:
      "Quality SS7 bricks and construction materials. Serving builders, contractors, developers, and homeowners.",
    siteName: "BrickPoint",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#faf8f5] text-[#2c2c2c] antialiased min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
        <WhatsAppFloat />
      </body>
    </html>
  );
}
