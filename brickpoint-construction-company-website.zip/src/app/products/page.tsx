import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Star } from "lucide-react";
import { PRODUCT_CATEGORIES } from "@/lib/data";

export const metadata: Metadata = {
  title: "Construction Materials | BrickPoint — SS7 Bricks & Supplies",
  description:
    "Explore BrickPoint's complete range of construction materials including SS7 bricks, cement, steel, sand, crush, and more. Order on WhatsApp.",
};

export default function ProductsPage() {
  const featured = PRODUCT_CATEGORIES.filter((c) => c.featured);
  const rest = PRODUCT_CATEGORIES.filter((c) => !c.featured);

  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-14 md:py-18 relative overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <Image
            src="/images/bricks-stacked.jpg"
            alt="Products"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/85" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Products</span>
          </nav>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our Construction Materials
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl">
            From SS7 bricks to complete construction solutions — quality materials for every project stage.
          </p>
        </div>
      </section>

      {/* Featured — Bricks / SS7 */}
      {featured.length > 0 && (
        <section className="py-12 bg-[#faf8f5]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <h2 className="text-xl font-bold text-[#0f1f3d] mb-6 flex items-center gap-2">
              <Star size={18} className="text-[#c0392b]" fill="#c0392b" />
              Featured Category
            </h2>
            <div className="grid grid-cols-1 gap-6">
              {featured.map((cat) => (
                <Link
                  key={cat.slug}
                  href={`/products/${cat.slug}`}
                  className="group relative rounded-2xl overflow-hidden bg-[#0f1f3d] border border-white/10 shadow-lg hover:shadow-2xl transition-all duration-300"
                >
                  <div className="relative h-64 md:h-80">
                    <Image
                      src={cat.image}
                      alt={cat.name}
                      fill
                      className="object-cover opacity-40 group-hover:opacity-50 transition-opacity"
                    />
                  </div>
                  <div className="absolute inset-0 flex flex-col justify-center p-8 md:p-12">
                    {cat.badge && (
                      <div className="inline-flex items-center gap-1.5 bg-[#c0392b] text-white text-xs font-bold px-3 py-1.5 rounded uppercase tracking-wider mb-4 w-fit">
                        <Star size={10} fill="white" />
                        {cat.badge}
                      </div>
                    )}
                    <h3 className="text-3xl md:text-4xl font-bold text-white mb-3">
                      {cat.name}
                    </h3>
                    <p className="text-gray-300 text-lg max-w-xl mb-6">{cat.description}</p>
                    <div className="inline-flex items-center gap-2 bg-[#c0392b] hover:bg-[#96281b] text-white font-semibold px-6 py-3 rounded-lg transition-colors w-fit group-hover:gap-3">
                      View {cat.name} <ArrowRight size={16} />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Categories */}
      <section className="py-12 bg-[#f0ebe3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="text-xl font-bold text-[#0f1f3d] mb-6">All Product Categories</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {rest.map((cat) => (
              <Link
                key={cat.slug}
                href={`/products/${cat.slug}`}
                className="group bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
              >
                <div className="relative h-36 overflow-hidden bg-gray-100">
                  <Image
                    src={cat.image}
                    alt={cat.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-2 left-2">
                    <span className="text-2xl">{cat.icon}</span>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-[#0f1f3d] text-sm group-hover:text-[#c0392b] transition-colors leading-tight">
                    {cat.name}
                  </h3>
                  <div className="mt-1.5 inline-flex items-center gap-1 text-[#c0392b] text-xs font-medium group-hover:gap-2 transition-all">
                    View <ArrowRight size={10} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* WhatsApp CTA */}
      <section className="py-14 bg-[#0f1f3d]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Can&#39;t Find What You&#39;re Looking For?
          </h2>
          <p className="text-gray-300 text-lg mb-8">
            Contact us on WhatsApp with your specific requirements. We will help you source the right materials.
          </p>
          <a
            href="https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20need%20help%20finding%20a%20specific%20construction%20material.%20Please%20assist."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold px-8 py-4 rounded-xl transition-all duration-200 text-base"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Inquire on WhatsApp
          </a>
        </div>
      </section>
    </>
  );
}
