import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Star, Phone, Tag } from "lucide-react";
import { db } from "@/db";
import { products, productCategories } from "@/db/schema";
import { eq } from "drizzle-orm";
import WhatsAppButton from "@/components/WhatsAppButton";
import { PRODUCT_CATEGORIES } from "@/lib/data";

interface Props {
  params: Promise<{ category: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { category } = await params;
  const cat = PRODUCT_CATEGORIES.find((c) => c.slug === category);
  return {
    title: `${cat?.name || "Products"} | BrickPoint Construction Materials`,
    description: cat?.description || "Quality construction materials from BrickPoint.",
  };
}

export async function generateStaticParams() {
  return PRODUCT_CATEGORIES.map((cat) => ({ category: cat.slug }));
}

export default async function CategoryPage({ params }: Props) {
  const { category } = await params;

  const categoryMeta = PRODUCT_CATEGORIES.find((c) => c.slug === category);
  if (!categoryMeta) notFound();

  let dbCategory = null;
  let productList: typeof products.$inferSelect[] = [];

  try {
    const cats = await db
      .select()
      .from(productCategories)
      .where(eq(productCategories.slug, category))
      .limit(1);

    if (cats.length) {
      dbCategory = cats[0];
      productList = await db
        .select()
        .from(products)
        .where(eq(products.categoryId, dbCategory.id))
        .orderBy(products.sortOrder);
    }
  } catch (_e) {
    // DB not available, use empty
  }

  const isBricks = category === "bricks";

  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-14 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src={categoryMeta.image}
            alt={categoryMeta.name}
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f1f3d] to-[#0f1f3d]/70" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6 flex-wrap">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/products" className="hover:text-white transition-colors">Products</Link>
            <span>/</span>
            <span className="text-white">{categoryMeta.name}</span>
          </nav>
          <div className="flex items-start gap-4">
            <span className="text-4xl">{categoryMeta.icon}</span>
            <div>
              {categoryMeta.badge && (
                <div className="inline-flex items-center gap-1.5 bg-[#c0392b] text-white text-xs font-bold px-3 py-1 rounded uppercase tracking-wider mb-3">
                  <Star size={10} fill="white" />
                  {categoryMeta.badge}
                </div>
              )}
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">
                {categoryMeta.name}
              </h1>
              <p className="text-gray-300 text-lg max-w-2xl">{categoryMeta.description}</p>
            </div>
          </div>
        </div>
      </section>

      {/* SS7 Special Banner for Bricks */}
      {isBricks && (
        <section className="py-10 bg-[#c0392b]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-5">
                <div className="bg-white rounded-2xl p-4 shadow-lg flex-shrink-0">
                  <div className="text-[#c0392b] font-black text-3xl">SS7</div>
                </div>
                <div>
                  <h2 className="text-white font-bold text-2xl">SS7 Bricks — Featured Brand</h2>
                  <p className="text-red-100">
                    Premium quality SS7 branded bricks from Masha Allah Bricks Co. &amp; Fine Bricks Co.
                  </p>
                </div>
              </div>
              <div className="flex gap-3 flex-shrink-0">
                <Link
                  href="/ss7-bricks"
                  className="inline-flex items-center gap-2 bg-white text-[#c0392b] hover:bg-gray-100 font-bold px-5 py-2.5 rounded-lg transition-colors text-sm"
                >
                  SS7 Details <ArrowRight size={14} />
                </Link>
                <a
                  href="https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20am%20interested%20in%20SS7%20Bricks.%20Please%20share%20availability%20and%20pricing."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold px-5 py-2.5 rounded-lg transition-colors text-sm"
                >
                  Order SS7 Bricks
                </a>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Products Grid */}
      <section className="py-14 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          {productList.length > 0 ? (
            <>
              <h2 className="text-2xl font-bold text-[#0f1f3d] mb-8">
                Available {categoryMeta.name}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {productList.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group"
                  >
                    <div className="relative h-52 overflow-hidden bg-gray-100">
                      <Image
                        src={
                          (product.images as string[])?.[0] ||
                          categoryMeta.image
                        }
                        alt={product.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {product.isSS7 && (
                        <div className="absolute top-3 left-3">
                          <span className="bg-[#c0392b] text-white text-xs font-bold px-2.5 py-1 rounded uppercase tracking-wide">
                            SS7 Brand
                          </span>
                        </div>
                      )}
                      {product.featured && !product.isSS7 && (
                        <div className="absolute top-3 left-3">
                          <span className="bg-[#b8860b] text-white text-xs font-bold px-2.5 py-1 rounded uppercase tracking-wide">
                            Featured
                          </span>
                        </div>
                      )}
                      {!product.available && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                          <span className="bg-white text-gray-800 font-semibold px-4 py-2 rounded-lg text-sm">
                            Currently Unavailable
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="p-5">
                      <h3 className="font-bold text-[#0f1f3d] text-lg mb-2 leading-snug">
                        {product.name}
                      </h3>
                      {product.productCode && (
                        <p className="text-gray-400 text-xs mb-3 flex items-center gap-1">
                          <Tag size={10} />
                          Code: {product.productCode}
                        </p>
                      )}
                      <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-2">
                        {product.shortDescription}
                      </p>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          {product.priceOnRequest ? (
                            <span className="text-[#0f1f3d] font-semibold text-sm">
                              Price on Request
                            </span>
                          ) : product.price ? (
                            <div>
                              <span className="text-[#c0392b] font-bold text-lg">
                                PKR {Number(product.price).toLocaleString()}
                              </span>
                              <span className="text-gray-500 text-xs ml-1">
                                / {product.priceUnit}
                              </span>
                            </div>
                          ) : (
                            <span className="text-gray-500 text-sm">Price on Request</span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link
                          href={`/products/${category}/${product.slug}`}
                          className="flex-1 text-center py-2.5 border-2 border-[#0f1f3d] text-[#0f1f3d] hover:bg-[#0f1f3d] hover:text-white font-semibold rounded-lg transition-all duration-200 text-sm"
                        >
                          View Details
                        </Link>
                        <WhatsAppButton
                          productName={product.name}
                          category={categoryMeta.name}
                          price={
                            product.priceOnRequest
                              ? "Price on Request"
                              : product.price
                              ? `PKR ${Number(product.price).toLocaleString()} / ${product.priceUnit}`
                              : "Price on Request"
                          }
                          variant="small"
                          className="flex-shrink-0"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-20">
              <div className="text-6xl mb-6">{categoryMeta.icon}</div>
              <h2 className="text-2xl font-bold text-[#0f1f3d] mb-4">
                {categoryMeta.name} — Coming Soon
              </h2>
              <p className="text-gray-600 text-lg max-w-md mx-auto mb-8">
                We are currently updating our {categoryMeta.name} catalog. Contact us directly
                on WhatsApp for available products and pricing.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href={`https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20am%20interested%20in%20${encodeURIComponent(categoryMeta.name)}.%20Please%20share%20available%20products%20and%20pricing.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold px-8 py-3.5 rounded-xl transition-all"
                >
                  Inquire on WhatsApp
                </a>
                <a
                  href="tel:03152850818"
                  className="inline-flex items-center justify-center gap-2 bg-[#0f1f3d] text-white hover:bg-[#1a3260] font-bold px-8 py-3.5 rounded-xl transition-all"
                >
                  <Phone size={16} />
                  Call 03152850818
                </a>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-14 bg-[#0f1f3d]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-2xl font-bold text-white mb-3">
            Need Help Ordering {categoryMeta.name}?
          </h2>
          <p className="text-gray-400 mb-8">
            Contact our sales team for pricing, availability, and bulk order inquiries.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href={`https://wa.me/923152850818?text=Assalam-o-Alaikum%20BrickPoint%2C%0AI%20need%20information%20about%20your%20${encodeURIComponent(categoryMeta.name)}.%20Please%20assist.`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold px-7 py-3.5 rounded-xl transition-all"
            >
              Order on WhatsApp
            </a>
            <a
              href="tel:03152850818"
              className="inline-flex items-center justify-center gap-2 border-2 border-white text-white hover:bg-white hover:text-[#0f1f3d] font-bold px-7 py-3.5 rounded-xl transition-all"
            >
              <Phone size={16} />
              Call 03152850818
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
