import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Star, Tag, CheckCircle, Package, ArrowRight, Phone } from "lucide-react";
import { db } from "@/db";
import { products, productCategories } from "@/db/schema";
import { eq } from "drizzle-orm";
import WhatsAppButton from "@/components/WhatsAppButton";
import { PRODUCT_CATEGORIES } from "@/lib/data";

interface Props {
  params: Promise<{ category: string; slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  try {
    const product = await db
      .select()
      .from(products)
      .where(eq(products.slug, slug))
      .limit(1);
    if (product.length) {
      return {
        title: `${product[0].name} | BrickPoint`,
        description: product[0].shortDescription || product[0].description || "",
      };
    }
  } catch (_e) {}
  return { title: "Product | BrickPoint" };
}

export default async function ProductDetailPage({ params }: Props) {
  const { category, slug } = await params;
  const categoryMeta = PRODUCT_CATEGORIES.find((c) => c.slug === category);

  let product: typeof products.$inferSelect | null = null;
  let relatedProducts: typeof products.$inferSelect[] = [];

  try {
    const result = await db
      .select()
      .from(products)
      .where(eq(products.slug, slug))
      .limit(1);

    if (!result.length) notFound();
    product = result[0];

    if (product.categoryId) {
      relatedProducts = await db
        .select()
        .from(products)
        .where(eq(products.categoryId, product.categoryId))
        .limit(4);
      relatedProducts = relatedProducts.filter((p) => p.slug !== slug);
    }
  } catch (_e) {
    notFound();
  }

  if (!product) notFound();

  const images = (product.images as string[]) || [];
  const features = (product.features as string[]) || [];
  const specs = (product.specifications as Record<string, string>) || {};

  const priceDisplay = product.priceOnRequest
    ? "Price on Request"
    : product.price
    ? `PKR ${Number(product.price).toLocaleString()} / ${product.priceUnit}`
    : "Price on Request";

  return (
    <>
      {/* Breadcrumb */}
      <div className="bg-[#0f1f3d] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <nav className="flex items-center gap-2 text-gray-400 text-sm flex-wrap">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <Link href="/products" className="hover:text-white transition-colors">Products</Link>
            <span>/</span>
            <Link href={`/products/${category}`} className="hover:text-white transition-colors">
              {categoryMeta?.name || category}
            </Link>
            <span>/</span>
            <span className="text-white">{product.name}</span>
          </nav>
        </div>
      </div>

      {/* Product Detail */}
      <section className="py-12 md:py-16 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Images */}
            <div>
              <div className="relative rounded-2xl overflow-hidden shadow-xl bg-gray-100">
                <Image
                  src={images[0] || categoryMeta?.image || "/images/hero-bricks.jpg"}
                  alt={product.name}
                  width={600}
                  height={500}
                  className="w-full h-80 md:h-96 object-cover"
                />
                {product.isSS7 && (
                  <div className="absolute top-4 left-4">
                    <span className="bg-[#c0392b] text-white text-sm font-bold px-3 py-1.5 rounded-lg uppercase tracking-wide flex items-center gap-1">
                      <Star size={12} fill="white" />
                      SS7 Brand
                    </span>
                  </div>
                )}
              </div>
              {images.length > 1 && (
                <div className="flex gap-3 mt-4 overflow-x-auto pb-2">
                  {images.map((img, i) => (
                    <div
                      key={i}
                      className="relative w-20 h-20 flex-shrink-0 rounded-xl overflow-hidden border-2 border-gray-200"
                    >
                      <Image
                        src={img}
                        alt={`${product.name} ${i + 1}`}
                        fill
                        className="object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info */}
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-4">
                {product.isSS7 && (
                  <span className="bg-[#c0392b] text-white text-xs font-bold px-3 py-1 rounded uppercase tracking-wider">
                    SS7 Brand
                  </span>
                )}
                {product.featured && (
                  <span className="bg-[#b8860b] text-white text-xs font-bold px-3 py-1 rounded uppercase tracking-wider">
                    Featured
                  </span>
                )}
                <span
                  className={`text-xs font-medium px-3 py-1 rounded ${
                    product.available
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {product.available ? "In Stock" : "Currently Unavailable"}
                </span>
              </div>

              <h1 className="text-3xl md:text-4xl font-bold text-[#0f1f3d] mb-3">
                {product.name}
              </h1>

              {product.productCode && (
                <p className="text-gray-400 text-sm mb-4 flex items-center gap-1">
                  <Tag size={12} />
                  Product Code: {product.productCode}
                </p>
              )}

              {/* Price */}
              <div className="bg-[#f0ebe3] rounded-xl p-4 mb-6">
                {product.priceOnRequest ? (
                  <div>
                    <p className="text-[#0f1f3d] font-bold text-xl">Price on Request</p>
                    <p className="text-gray-500 text-sm mt-1">
                      Contact us for current pricing and availability
                    </p>
                  </div>
                ) : product.price ? (
                  <div>
                    <p className="text-[#c0392b] font-black text-3xl">
                      PKR {Number(product.price).toLocaleString()}
                    </p>
                    <p className="text-gray-500 text-sm mt-1">per {product.priceUnit}</p>
                  </div>
                ) : (
                  <div>
                    <p className="text-[#0f1f3d] font-bold text-xl">Price on Request</p>
                    <p className="text-gray-500 text-sm mt-1">
                      Contact us for current pricing
                    </p>
                  </div>
                )}
              </div>

              {/* Short description */}
              {product.shortDescription && (
                <p className="text-gray-600 leading-relaxed mb-6">
                  {product.shortDescription}
                </p>
              )}

              {/* Features */}
              {features.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-semibold text-[#0f1f3d] mb-3">Key Features</h3>
                  <div className="grid grid-cols-1 gap-2">
                    {features.map((feat) => (
                      <div key={feat} className="flex items-center gap-2 text-sm text-gray-700">
                        <CheckCircle size={15} className="text-[#c0392b] flex-shrink-0" />
                        {feat}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <WhatsAppButton
                  productName={product.name}
                  category={categoryMeta?.name || category}
                  price={priceDisplay}
                  variant="primary"
                  className="flex-1 justify-center"
                />
                <a
                  href="tel:03152850818"
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-[#0f1f3d] hover:bg-[#1a3260] text-white font-semibold py-2.5 rounded-lg transition-all text-sm"
                >
                  <Phone size={16} />
                  Call to Order
                </a>
              </div>

              {/* Specs */}
              {Object.keys(specs).length > 0 && (
                <div className="border border-gray-200 rounded-xl overflow-hidden">
                  <div className="bg-[#0f1f3d] px-4 py-3">
                    <h3 className="font-semibold text-white text-sm flex items-center gap-2">
                      <Package size={14} />
                      Specifications
                    </h3>
                  </div>
                  <div className="divide-y divide-gray-100">
                    {Object.entries(specs).map(([key, value]) => (
                      <div key={key} className="flex">
                        <div className="w-2/5 px-4 py-3 bg-gray-50 text-sm font-medium text-gray-700">
                          {key}
                        </div>
                        <div className="w-3/5 px-4 py-3 text-sm text-gray-600">
                          {value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Full Description */}
          {product.description && (
            <div className="mt-12 bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
              <h2 className="text-2xl font-bold text-[#0f1f3d] mb-5">Product Description</h2>
              <div className="prose prose-gray max-w-none text-gray-600 leading-relaxed whitespace-pre-line">
                {product.description}
              </div>
            </div>
          )}

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold text-[#0f1f3d] mb-6">Related Products</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {relatedProducts.slice(0, 3).map((rel) => (
                  <Link
                    key={rel.id}
                    href={`/products/${category}/${rel.slug}`}
                    className="group bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-300"
                  >
                    <div className="relative h-40 overflow-hidden bg-gray-100">
                      <Image
                        src={
                          (rel.images as string[])?.[0] ||
                          categoryMeta?.image ||
                          "/images/hero-bricks.jpg"
                        }
                        alt={rel.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-[#0f1f3d] text-sm group-hover:text-[#c0392b] transition-colors">
                        {rel.name}
                      </h3>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-gray-500 text-xs">
                          {rel.priceOnRequest ? "Price on Request" : rel.price ? `PKR ${Number(rel.price).toLocaleString()}` : "Contact for Price"}
                        </span>
                        <span className="text-[#c0392b] text-xs font-medium flex items-center gap-1">
                          View <ArrowRight size={10} />
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
