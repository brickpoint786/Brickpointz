import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Phone, MapPin } from "lucide-react";
import ContactForm from "./ContactForm";
import { SOCIAL_LINKS } from "@/lib/data";

export const metadata: Metadata = {
  title: "Contact Us | BrickPoint — SS7 Bricks & Construction Materials",
  description:
    "Contact BrickPoint for SS7 bricks and construction materials. WhatsApp, phone, and contact form. Speak to our sales team today.",
};

const FacebookIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
  </svg>
);

const InstagramIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
  </svg>
);

const TikTokIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
    <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
  </svg>
);

const XIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.742l7.73-8.835L1.254 2.25H8.08l4.213 5.567z" />
  </svg>
);

const WhatsAppIcon = ({ size = 20 }: { size?: number }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

export default function ContactPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#0f1f3d] py-14 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/about-team.jpg"
            alt="Contact BrickPoint"
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-[#0f1f3d]/80" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex items-center gap-2 text-gray-400 text-sm mb-6">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <span>/</span>
            <span className="text-white">Contact Us</span>
          </nav>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Let&apos;s Build Something Stronger
          </h1>
          <p className="text-gray-300 text-lg max-w-xl">
            Reach out to our team for product pricing, availability, bulk orders, and general inquiries.
          </p>
        </div>
      </section>

      {/* Main content */}
      <section className="py-14 md:py-20 bg-[#faf8f5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Left — Contact info */}
            <div className="space-y-6">
              {/* WhatsApp */}
              <div className="bg-[#0f1f3d] rounded-2xl p-6">
                <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                  <WhatsAppIcon size={18} />
                  Order on WhatsApp
                </h3>
                <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                  The fastest way to reach us. Send your order or inquiry directly on WhatsApp.
                </p>
                <a
                  href="https://wa.me/923152850818"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1da855] text-white font-bold py-3 rounded-xl transition-all text-sm"
                >
                  <WhatsAppIcon size={16} />
                  Chat on WhatsApp
                </a>
              </div>

              {/* Phone */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 className="text-[#0f1f3d] font-bold text-lg mb-4 flex items-center gap-2">
                  <Phone size={18} className="text-[#c0392b]" />
                  Call Us
                </h3>
                <a
                  href="tel:03152850818"
                  className="text-2xl font-black text-[#c0392b] hover:text-[#96281b] transition-colors block mb-2"
                >
                  03152850818
                </a>
                <p className="text-gray-500 text-sm">
                  CEO: Syed Iftikhar Haider
                </p>
                <p className="text-gray-500 text-sm">
                  Sales: Qasim Iqbal
                </p>
              </div>

              {/* Locations */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 className="text-[#0f1f3d] font-bold text-lg mb-4 flex items-center gap-2">
                  <MapPin size={18} className="text-[#c0392b]" />
                  Our Locations
                </h3>
                <div className="space-y-3 text-sm text-gray-600">
                  <div>
                    <p className="font-semibold text-[#0f1f3d]">Masha Allah Bricks — Bhatta 1</p>
                    <p>Ram Thaman</p>
                  </div>
                  <div>
                    <p className="font-semibold text-[#0f1f3d]">Fine Bricks Co. — Bhatta 2</p>
                    <p>Raja Jang</p>
                  </div>
                  <div>
                    <p className="font-semibold text-[#0f1f3d]">BrickPoint Office</p>
                    <Link href="/locations" className="text-[#c0392b] hover:text-[#96281b] text-xs">
                      View All Locations →
                    </Link>
                  </div>
                </div>
              </div>

              {/* Social */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 className="text-[#0f1f3d] font-bold text-lg mb-4">Follow Us</h3>
                <div className="flex gap-3 flex-wrap">
                  {[
                    { href: SOCIAL_LINKS.facebook, icon: <FacebookIcon />, label: "Facebook", color: "#1877F2" },
                    { href: SOCIAL_LINKS.instagram, icon: <InstagramIcon />, label: "Instagram", color: "#E1306C" },
                    { href: SOCIAL_LINKS.twitter, icon: <XIcon />, label: "X", color: "#000" },
                    { href: SOCIAL_LINKS.tiktok, icon: <TikTokIcon />, label: "TikTok", color: "#000" },
                    { href: SOCIAL_LINKS.whatsapp, icon: <WhatsAppIcon />, label: "WhatsApp", color: "#25D366" },
                  ].map((s) => (
                    <a
                      key={s.label}
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={s.label}
                      className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center justify-center transition-colors text-[#0f1f3d]"
                    >
                      {s.icon}
                    </a>
                  ))}
                </div>
                <a
                  href={SOCIAL_LINKS.whatsappChannel}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 flex items-center justify-center gap-2 bg-[#25D366]/10 hover:bg-[#25D366]/20 text-[#25D366] font-semibold py-2.5 rounded-xl transition-all text-sm w-full"
                >
                  <WhatsAppIcon size={14} />
                  Join WhatsApp Channel
                </a>
              </div>
            </div>

            {/* Right — Contact Form */}
            <div className="lg:col-span-2">
              <ContactForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
