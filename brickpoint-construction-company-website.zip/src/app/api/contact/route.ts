import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, phone, email, product, message } = body;

    if (!name || (!phone && !email)) {
      return NextResponse.json(
        { error: "Name and at least one contact method (phone or email) are required." },
        { status: 400 }
      );
    }

    await db.insert(contactMessages).values({
      name,
      phone: phone || null,
      email: email || null,
      product: product || null,
      message: message || null,
    });

    return NextResponse.json({
      success: true,
      message: "Your message has been received. We will contact you shortly.",
    });
  } catch (error) {
    console.error("Contact form error:", error);
    return NextResponse.json(
      { error: "Failed to submit message. Please try WhatsApp or phone." },
      { status: 500 }
    );
  }
}
