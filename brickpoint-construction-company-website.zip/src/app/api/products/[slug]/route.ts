import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, productCategories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  try {
    const product = await db
      .select()
      .from(products)
      .where(eq(products.slug, slug))
      .limit(1);

    if (!product.length) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    let category = null;
    if (product[0].categoryId) {
      const cat = await db
        .select()
        .from(productCategories)
        .where(eq(productCategories.id, product[0].categoryId))
        .limit(1);
      category = cat[0] || null;
    }

    // Related products
    const related = product[0].categoryId
      ? await db
          .select()
          .from(products)
          .where(eq(products.categoryId, product[0].categoryId))
          .limit(4)
      : [];

    return NextResponse.json({
      product: product[0],
      category,
      related: related.filter((p) => p.slug !== slug),
    });
  } catch (error) {
    console.error("Error fetching product:", error);
    return NextResponse.json({ error: "Failed to fetch product" }, { status: 500 });
  }
}
