import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, productCategories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const categorySlug = searchParams.get("category");

  try {
    if (categorySlug) {
      const category = await db
        .select()
        .from(productCategories)
        .where(eq(productCategories.slug, categorySlug))
        .limit(1);

      if (!category.length) {
        return NextResponse.json({ products: [], category: null });
      }

      const productList = await db
        .select()
        .from(products)
        .where(eq(products.categoryId, category[0].id))
        .orderBy(products.sortOrder);

      return NextResponse.json({
        products: productList,
        category: category[0],
      });
    }

    const productList = await db
      .select({
        id: products.id,
        name: products.name,
        slug: products.slug,
        shortDescription: products.shortDescription,
        price: products.price,
        priceUnit: products.priceUnit,
        priceOnRequest: products.priceOnRequest,
        images: products.images,
        available: products.available,
        featured: products.featured,
        isSS7: products.isSS7,
        categoryId: products.categoryId,
      })
      .from(products)
      .orderBy(products.sortOrder);

    return NextResponse.json({ products: productList });
  } catch (error) {
    console.error("Error fetching products:", error);
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 });
  }
}
