import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  timestamp,
  integer,
  decimal,
  json,
} from "drizzle-orm/pg-core";

// Product Categories
export const productCategories = pgTable("product_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  image: text("image"),
  featured: boolean("featured").default(false),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Products
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  categoryId: integer("category_id").references(() => productCategories.id),
  description: text("description"),
  shortDescription: text("short_description"),
  price: decimal("price", { precision: 10, scale: 2 }),
  priceUnit: varchar("price_unit", { length: 100 }).default("Per Item"),
  priceOnRequest: boolean("price_on_request").default(false),
  productCode: varchar("product_code", { length: 100 }),
  images: json("images").$type<string[]>().default([]),
  features: json("features").$type<string[]>().default([]),
  specifications: json("specifications").$type<Record<string, string>>().default({}),
  available: boolean("available").default(true),
  featured: boolean("featured").default(false),
  isSS7: boolean("is_ss7").default(false),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  category: varchar("category", { length: 100 }),
  location: varchar("location", { length: 255 }),
  description: text("description"),
  image: text("image"),
  gallery: json("gallery").$type<string[]>().default([]),
  materialsUsed: json("materials_used").$type<string[]>().default([]),
  featured: boolean("featured").default(false),
  illustrative: boolean("illustrative").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Blog Posts
export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  slug: varchar("slug", { length: 500 }).notNull().unique(),
  excerpt: text("excerpt"),
  content: text("content"),
  featuredImage: text("featured_image"),
  category: varchar("category", { length: 100 }),
  author: varchar("author", { length: 255 }).default("BrickPoint Team"),
  readingTime: integer("reading_time").default(5),
  published: boolean("published").default(false),
  featured: boolean("featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Contact Messages
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 255 }),
  product: varchar("product", { length: 255 }),
  message: text("message"),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});
