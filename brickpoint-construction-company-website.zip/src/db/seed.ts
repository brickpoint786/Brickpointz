import { db } from "./index";
import {
  productCategories,
  products,
  projects,
  blogPosts,
} from "./schema";

async function seed() {
  console.log("Seeding database...");

  // Clear existing data
  await db.delete(products);
  await db.delete(productCategories);
  await db.delete(projects);
  await db.delete(blogPosts);

  // Insert product categories
  const categories = await db
    .insert(productCategories)
    .values([
      {
        name: "Bricks",
        slug: "bricks",
        description:
          "Premium quality bricks including SS7 branded bricks for all construction needs.",
        image: "/images/bricks-stacked.jpg",
        featured: true,
        sortOrder: 1,
      },
      {
        name: "Cement",
        slug: "cement",
        description:
          "High-quality cement for residential and commercial construction projects.",
        image: "/images/cement-bags.jpg",
        featured: false,
        sortOrder: 2,
      },
      {
        name: "Crush / Bajri",
        slug: "crush",
        description:
          "Construction grade crush and bajri for foundations and concrete mixing.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 3,
      },
      {
        name: "Sand / Rait",
        slug: "sand",
        description:
          "Fine and coarse sand for plastering, concrete, and construction use.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 4,
      },
      {
        name: "Steel",
        slug: "steel",
        description:
          "Structural steel, rebar, and reinforcement materials for construction.",
        image: "/images/steel-rods.jpg",
        featured: false,
        sortOrder: 5,
      },
      {
        name: "Electric Pipes",
        slug: "electric-pipes",
        description:
          "Conduit and electrical pipes for safe electrical installations.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 6,
      },
      {
        name: "Plumbing Pipes & Fittings",
        slug: "plumbing-pipes",
        description:
          "Complete plumbing solutions including pipes, fittings, and accessories.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 7,
      },
      {
        name: "Construction Chemicals",
        slug: "construction-chemicals",
        description:
          "Admixtures, waterproofing chemicals, and construction additives.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 8,
      },
      {
        name: "Insulation & Membrane",
        slug: "insulation-membrane",
        description:
          "Thermal insulation, waterproofing membranes, and protective coatings.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 9,
      },
      {
        name: "Cables & Wires",
        slug: "cables-wires",
        description:
          "Electrical cables and wiring solutions for residential and commercial use.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 10,
      },
      {
        name: "Paints",
        slug: "paints",
        description:
          "Interior and exterior paints, primers, and finishing solutions.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 11,
      },
      {
        name: "Lights",
        slug: "lights",
        description:
          "LED lights, fixtures, and lighting solutions for all spaces.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 12,
      },
      {
        name: "Switches & Sockets",
        slug: "switches-sockets",
        description:
          "Quality switches, sockets, and electrical accessories for modern homes.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 13,
      },
      {
        name: "Other Construction Items",
        slug: "other-items",
        description:
          "Additional construction materials and accessories for your project.",
        image: "/images/hero-bricks.jpg",
        featured: false,
        sortOrder: 14,
      },
    ])
    .returning();

  const bricksCat = categories.find((c) => c.slug === "bricks");
  const cementCat = categories.find((c) => c.slug === "cement");
  const steelCat = categories.find((c) => c.slug === "steel");
  const crushCat = categories.find((c) => c.slug === "crush");
  const sandCat = categories.find((c) => c.slug === "sand");

  // Insert products
  await db.insert(products).values([
    // SS7 Bricks
    {
      name: "SS7 Bricks — Standard",
      slug: "ss7-bricks-standard",
      categoryId: bricksCat?.id,
      shortDescription:
        "Premium SS7 branded standard bricks for residential and commercial construction.",
      description:
        "SS7 Bricks are a trusted choice for construction projects where quality, consistency, and dependable supply matter. Manufactured under strict quality control, these bricks offer excellent dimensional consistency and reliable performance for walls, foundations, and structural applications.\n\nBrickPoint is the authorized supplier of SS7 branded bricks through Masha Allah Bricks Company and Fine Bricks Company, ensuring you receive genuine SS7 bricks with every order.",
      priceOnRequest: true,
      priceUnit: "Per 1,000 Bricks",
      productCode: "SS7-STD",
      images: ["/images/ss7-brick.jpg", "/images/bricks-stacked.jpg"],
      features: [
        "SS7 Branded Quality",
        "Consistent Dimensions",
        "Reliable Supply",
        "Suitable for Load-Bearing Walls",
        "Available in Bulk Orders",
      ],
      specifications: {
        Brand: "SS7",
        Type: "Standard Clay Brick",
        Supplier: "BrickPoint",
        Companies: "Masha Allah Bricks Co. / Fine Bricks Co.",
      },
      available: true,
      featured: true,
      isSS7: true,
      sortOrder: 1,
    },
    // General Bricks
    {
      name: "Standard Construction Bricks",
      slug: "standard-construction-bricks",
      categoryId: bricksCat?.id,
      shortDescription:
        "Quality standard bricks for general construction use.",
      description:
        "High quality standard construction bricks suitable for residential and commercial buildings. Consistent in size and strength, these bricks are ideal for walls, partitions, and general construction work.",
      priceOnRequest: true,
      priceUnit: "Per 1,000 Bricks",
      productCode: "BRICK-STD",
      images: ["/images/bricks-stacked.jpg"],
      features: [
        "Consistent Quality",
        "Bulk Availability",
        "Suitable for All Construction Types",
      ],
      specifications: {
        Type: "Standard Clay Brick",
        Supplier: "BrickPoint",
      },
      available: true,
      featured: false,
      isSS7: false,
      sortOrder: 2,
    },
    // Cement
    {
      name: "Ordinary Portland Cement (OPC)",
      slug: "ordinary-portland-cement",
      categoryId: cementCat?.id,
      shortDescription:
        "Premium Ordinary Portland Cement for all construction applications.",
      description:
        "High-quality Ordinary Portland Cement suitable for general construction, concrete work, plastering, and masonry. Available in standard 50kg bags from leading brands.",
      priceOnRequest: true,
      priceUnit: "Per Bag (50kg)",
      productCode: "CEM-OPC",
      images: ["/images/cement-bags.jpg"],
      features: [
        "Standard 50kg Bags",
        "For General Construction",
        "Plastering & Concrete",
        "Reliable Brands Available",
      ],
      specifications: {
        Type: "Ordinary Portland Cement",
        "Bag Weight": "50 kg",
        Supplier: "BrickPoint",
      },
      available: true,
      featured: false,
      isSS7: false,
      sortOrder: 1,
    },
    // Steel
    {
      name: "Deformed Steel Bars (Rebar)",
      slug: "deformed-steel-bars",
      categoryId: steelCat?.id,
      shortDescription:
        "Structural deformed steel bars for reinforced concrete construction.",
      description:
        "High-quality deformed steel reinforcement bars (rebar) available in various sizes for structural concrete applications. Suitable for foundations, beams, columns, and slabs.",
      priceOnRequest: true,
      priceUnit: "Per Ton",
      productCode: "STEEL-REBAR",
      images: ["/images/steel-rods.jpg"],
      features: [
        "Available in Multiple Sizes",
        "High Tensile Strength",
        "For Structural Use",
        "Bulk Orders Available",
      ],
      specifications: {
        Type: "Deformed Reinforcement Bar",
        Sizes: "10mm, 12mm, 16mm, 20mm, 25mm",
        Supplier: "BrickPoint",
      },
      available: true,
      featured: false,
      isSS7: false,
      sortOrder: 1,
    },
    // Crush
    {
      name: "Construction Crush (Bajri)",
      slug: "construction-crush",
      categoryId: crushCat?.id,
      shortDescription:
        "Quality crush/bajri for concrete mixing and foundation work.",
      description:
        "Construction grade crush (bajri) suitable for concrete mixing, foundation filling, and road base applications. Available in various grades.",
      priceOnRequest: true,
      priceUnit: "Per Cubic Foot",
      productCode: "CRUSH-01",
      images: ["/images/hero-bricks.jpg"],
      features: [
        "Multiple Grades Available",
        "For Concrete Mixing",
        "Foundation Use",
        "Bulk Delivery",
      ],
      specifications: {
        Type: "Construction Crush / Bajri",
        Supplier: "BrickPoint",
      },
      available: true,
      featured: false,
      isSS7: false,
      sortOrder: 1,
    },
    // Sand
    {
      name: "Construction Sand (Rait)",
      slug: "construction-sand",
      categoryId: sandCat?.id,
      shortDescription:
        "Fine construction sand for plastering and concrete work.",
      description:
        "Quality construction sand (rait) suitable for plastering, concrete preparation, and masonry work. Clean and properly graded for construction use.",
      priceOnRequest: true,
      priceUnit: "Per Cubic Foot",
      productCode: "SAND-01",
      images: ["/images/hero-bricks.jpg"],
      features: [
        "Clean & Graded",
        "For Plastering",
        "For Concrete Mixing",
        "Bulk Availability",
      ],
      specifications: {
        Type: "Construction Sand",
        Supplier: "BrickPoint",
      },
      available: true,
      featured: false,
      isSS7: false,
      sortOrder: 1,
    },
  ]);

  // Insert projects
  await db.insert(projects).values([
    {
      title: "Modern Residential Villa — DHA Lahore",
      slug: "modern-villa-dha-lahore",
      category: "Residential",
      location: "DHA Lahore",
      description:
        "A modern residential villa construction project featuring premium brickwork and quality construction materials. SS7 bricks were used for the main structural walls, delivering consistent quality and professional results.",
      image: "/images/construction-project.jpg",
      materialsUsed: ["SS7 Bricks", "Cement", "Steel", "Sand", "Crush"],
      featured: true,
      illustrative: true,
      sortOrder: 1,
    },
    {
      title: "Commercial Development — Bahria Town Lahore",
      slug: "commercial-development-bahria-town",
      category: "Commercial",
      location: "Bahria Town Lahore",
      description:
        "A commercial building project in Bahria Town Lahore, showcasing the use of quality construction materials for multi-storey commercial development.",
      image: "/images/hero-bricks.jpg",
      materialsUsed: ["Bricks", "Cement", "Steel Rebar", "Construction Chemicals"],
      featured: true,
      illustrative: true,
      sortOrder: 2,
    },
    {
      title: "Residential Housing Project — Lake City Lahore",
      slug: "housing-project-lake-city",
      category: "Residential",
      location: "Lake City Lahore",
      description:
        "Premium residential construction featuring quality brickwork and modern construction materials for a housing project in Lake City Lahore.",
      image: "/images/brick-factory.jpg",
      materialsUsed: ["SS7 Bricks", "Cement", "Plumbing Pipes", "Paints"],
      featured: false,
      illustrative: true,
      sortOrder: 3,
    },
    {
      title: "Brickwork Masonry — Etihad Town Lahore",
      slug: "brickwork-etihad-town",
      category: "Brickwork",
      location: "Etihad Town Lahore",
      description:
        "Expert brickwork and masonry using SS7 branded bricks for a residential project in Etihad Town, Lahore.",
      image: "/images/bricks-stacked.jpg",
      materialsUsed: ["SS7 Bricks", "Cement", "Sand"],
      featured: false,
      illustrative: true,
      sortOrder: 4,
    },
  ]);

  // Insert blog posts
  await db.insert(blogPosts).values([
    {
      title: "How to Choose Quality Bricks for Your Home Construction",
      slug: "how-to-choose-quality-bricks",
      excerpt:
        "Choosing the right bricks is one of the most important decisions in home construction. Learn what to look for when selecting bricks for your project.",
      content: `<p>When building a home, the quality of bricks you use will directly impact the strength, durability, and appearance of your walls. Here are the key factors to consider when choosing bricks for your construction project.</p>

<h2>1. Check Dimensional Consistency</h2>
<p>Good quality bricks should have consistent dimensions. Inconsistent brick sizes make it difficult for masons to build straight walls and can affect the structural integrity of your building.</p>

<h2>2. Look at Surface Quality</h2>
<p>The surface of quality bricks should be smooth and free from large cracks. Minor surface variations are acceptable, but deep cracks or crumbling edges indicate poor quality.</p>

<h2>3. Consider the Source</h2>
<p>Always buy bricks from a reputable supplier. Established suppliers like BrickPoint ensure that you receive genuine quality bricks from trusted manufacturers.</p>

<h2>4. SS7 Bricks — A Reliable Choice</h2>
<p>SS7 branded bricks from BrickPoint's Masha Allah Bricks Company and Fine Bricks Company are a reliable choice for residential and commercial construction. They are known for consistency and dependable supply.</p>

<h2>Conclusion</h2>
<p>Choosing the right bricks from the start will save you time, money, and headaches during construction. Contact BrickPoint on WhatsApp at 03152850818 to discuss your brick requirements.</p>`,
      featuredImage: "/images/bricks-stacked.jpg",
      category: "Bricks",
      author: "BrickPoint Team",
      readingTime: 5,
      published: true,
      featured: true,
    },
    {
      title: "SS7 Bricks and Their Role in Construction",
      slug: "ss7-bricks-role-in-construction",
      excerpt:
        "SS7 bricks have become a recognized name in the construction industry. Discover what makes them a preferred choice for builders and contractors.",
      content: `<p>In the construction industry, the SS7 brick brand has built a reputation for quality and consistency. BrickPoint, through Masha Allah Bricks Company and Fine Bricks Company, is proud to supply SS7 branded bricks to builders and contractors across the region.</p>

<h2>What Are SS7 Bricks?</h2>
<p>SS7 bricks are a branded variety of red clay bricks manufactured under quality-focused production processes. The SS7 mark signifies a commitment to consistency in dimensions, quality, and supply reliability.</p>

<h2>Why Choose SS7 Bricks?</h2>
<p>Builders and contractors choose SS7 bricks because of their consistent quality and reliable availability. When you order SS7 bricks from BrickPoint, you can trust that the supply will be consistent throughout your project.</p>

<h2>Applications</h2>
<p>SS7 bricks are suitable for a wide range of construction applications including residential homes, commercial buildings, boundary walls, and general masonry work.</p>

<h2>Order SS7 Bricks</h2>
<p>To order SS7 bricks or inquire about pricing and availability, contact BrickPoint on WhatsApp: 03152850818</p>`,
      featuredImage: "/images/ss7-brick.jpg",
      category: "Bricks",
      author: "BrickPoint Team",
      readingTime: 4,
      published: true,
      featured: true,
    },
    {
      title: "Essential Construction Materials for Building a House in Pakistan",
      slug: "essential-construction-materials-pakistan",
      excerpt:
        "Planning to build a house? Here is a comprehensive overview of the essential construction materials you will need for a successful project.",
      content: `<p>Building a house requires careful planning and the right materials. Here is an overview of the essential construction materials needed for most residential construction projects in Pakistan.</p>

<h2>1. Bricks</h2>
<p>Bricks are the foundation of most walls in Pakistani homes. Quality bricks like SS7 bricks from BrickPoint provide the structural base for your entire building.</p>

<h2>2. Cement</h2>
<p>Cement is essential for binding bricks, preparing concrete, and plastering walls. OPC (Ordinary Portland Cement) is the most common choice for general construction.</p>

<h2>3. Sand (Rait)</h2>
<p>Sand is used in concrete mixes and plastering. Different grades of sand are used for different applications.</p>

<h2>4. Crush (Bajri)</h2>
<p>Crush or bajri is an essential component of concrete mixes, particularly for foundations, slabs, and structural elements.</p>

<h2>5. Steel Rebar</h2>
<p>Steel reinforcement bars are used in reinforced concrete for foundations, beams, columns, and slabs to add tensile strength.</p>

<h2>Contact BrickPoint</h2>
<p>BrickPoint supplies a comprehensive range of construction materials. Contact us on WhatsApp at 03152850818 for pricing and availability.</p>`,
      featuredImage: "/images/construction-project.jpg",
      category: "Construction Materials",
      author: "BrickPoint Team",
      readingTime: 6,
      published: true,
      featured: false,
    },
    {
      title: "Construction Material Buying Guide for Homeowners",
      slug: "construction-material-buying-guide",
      excerpt:
        "A practical guide for homeowners on how to buy construction materials efficiently, avoid common mistakes, and get the best value.",
      content: `<p>Buying construction materials for the first time can be overwhelming. This guide will help you navigate the process more confidently.</p>

<h2>Plan Before You Buy</h2>
<p>Always have a detailed plan and quantity estimate before purchasing materials. Over-buying wastes money; under-buying causes project delays.</p>

<h2>Buy from Reputable Suppliers</h2>
<p>Always source your materials from established, reputable suppliers. BrickPoint has been serving builders and contractors through Masha Allah Bricks Company and Fine Bricks Company.</p>

<h2>Compare Prices</h2>
<p>Get price quotes from multiple suppliers before finalizing your purchase. BrickPoint offers competitive pricing — contact us on WhatsApp for the latest rates.</p>

<h2>Plan Your Deliveries</h2>
<p>Coordinate material deliveries with your construction schedule to minimize storage issues and material damage.</p>

<h2>Get in Touch</h2>
<p>For construction material inquiries and pricing, contact BrickPoint on WhatsApp: 03152850818</p>`,
      featuredImage: "/images/brick-factory.jpg",
      category: "Building Tips",
      author: "BrickPoint Team",
      readingTime: 5,
      published: true,
      featured: false,
    },
    {
      title: "Understanding Bricks, Cement, Sand, and Crush in Construction",
      slug: "understanding-bricks-cement-sand-crush",
      excerpt:
        "Learn about the four fundamental construction materials — bricks, cement, sand, and crush — and how they work together in building construction.",
      content: `<p>Every construction project relies on a combination of essential materials. Understanding how bricks, cement, sand, and crush work together will help you make better decisions for your project.</p>

<h2>Bricks</h2>
<p>Bricks form the walls of your building. Quality bricks provide structural strength and a clean finish. SS7 bricks from BrickPoint are a trusted choice for many construction projects.</p>

<h2>Cement</h2>
<p>Cement acts as the binding agent. It holds bricks together in mortar and binds aggregates in concrete. The quality and grade of cement significantly impacts structural performance.</p>

<h2>Sand (Rait)</h2>
<p>Sand is mixed with cement to create mortar for bricklaying and plaster for wall finishing. Different applications require different sand grades.</p>

<h2>Crush / Bajri</h2>
<p>Crush is mixed with cement and sand to create concrete for foundations, slabs, columns, and beams. The correct ratio of these materials is essential for structural integrity.</p>

<h2>Get All Your Materials from One Source</h2>
<p>BrickPoint can help you source all these essential construction materials. Contact us on WhatsApp at 03152850818 for pricing and delivery information.</p>`,
      featuredImage: "/images/bricks-stacked.jpg",
      category: "Construction Planning",
      author: "BrickPoint Team",
      readingTime: 7,
      published: true,
      featured: false,
    },
  ]);

  console.log("Seeding completed successfully!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});
