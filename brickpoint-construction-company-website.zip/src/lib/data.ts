// Central data store for BrickPoint website
// All product categories with their metadata

export const WHATSAPP_NUMBER = "923152850818";
export const PHONE_NUMBER = "03152850818";

export const SOCIAL_LINKS = {
  facebook: "https://www.facebook.com/brickpoint.pk/",
  instagram: "https://www.instagram.com/brickpoint.pk/",
  twitter: "https://x.com/BrickPointPK",
  tiktok: "https://www.tiktok.com/@brickpoint.pk",
  whatsapp: "https://wa.me/923152850818",
  whatsappChannel: "https://whatsapp.com/channel/0029VbDHPm45a23w88ADzK32",
};

export const LOCATIONS = [
  {
    id: 1,
    name: "Masha Allah Bricks Company — Bhatta 1",
    company: "Masha Allah Bricks Company",
    area: "Ram Thaman",
    mapsLink: "https://maps.app.goo.gl/6Pi5BNTsxPRkn1cn7?g_st=awb",
    type: "factory",
  },
  {
    id: 2,
    name: "Masha Allah Bricks Company — Bhatta 3",
    company: "Masha Allah Bricks Company",
    area: null,
    mapsLink: "https://google.com/maps?q=31.2328,74.3169424&z=17&hl=en",
    type: "factory",
  },
  {
    id: 3,
    name: "Fine Bricks Company — Bhatta 2",
    company: "Fine Bricks Company",
    area: "Raja Jang",
    mapsLink: "https://maps.app.goo.gl/SDaxqVM55qXt66wW8?g_st=awb",
    type: "factory",
  },
  {
    id: 4,
    name: "BrickPoint Office",
    company: "BrickPoint",
    area: null,
    mapsLink: "https://maps.app.goo.gl/GACXw15YxyV4bK5t8?g_st=awb",
    type: "office",
  },
];

export const PRODUCT_CATEGORIES = [
  {
    name: "Bricks",
    slug: "bricks",
    icon: "🧱",
    description: "Premium quality bricks including SS7 branded bricks for all construction needs.",
    image: "/images/bricks-stacked.jpg",
    featured: true,
    badge: "SS7 Brand",
  },
  {
    name: "Cement",
    slug: "cement",
    icon: "🏗️",
    description: "High-quality cement from leading brands for residential and commercial projects.",
    image: "/images/cement-bags.jpg",
    featured: false,
  },
  {
    name: "Crush / Bajri",
    slug: "crush",
    icon: "⛏️",
    description: "Construction grade crush and bajri for foundations and concrete mixing.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Sand / Rait",
    slug: "sand",
    icon: "🪨",
    description: "Fine and coarse sand for plastering, concrete, and construction use.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Steel",
    slug: "steel",
    icon: "🔩",
    description: "Structural steel, rebar, and reinforcement materials for construction.",
    image: "/images/steel-rods.jpg",
    featured: false,
  },
  {
    name: "Electric Pipes",
    slug: "electric-pipes",
    icon: "⚡",
    description: "Conduit and electrical pipes for safe electrical installations.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Plumbing Pipes & Fittings",
    slug: "plumbing-pipes",
    icon: "🔧",
    description: "Complete plumbing solutions including pipes, fittings, and accessories.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Construction Chemicals",
    slug: "construction-chemicals",
    icon: "🧪",
    description: "Admixtures, waterproofing chemicals, and construction additives.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Insulation & Membrane",
    slug: "insulation-membrane",
    icon: "🛡️",
    description: "Thermal insulation, waterproofing membranes, and protective coatings.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Cables & Wires",
    slug: "cables-wires",
    icon: "🔌",
    description: "Electrical cables and wiring solutions for residential and commercial use.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Paints",
    slug: "paints",
    icon: "🎨",
    description: "Interior and exterior paints, primers, and finishing solutions.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Lights",
    slug: "lights",
    icon: "💡",
    description: "LED lights, fixtures, and lighting solutions for all spaces.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Switches & Sockets",
    slug: "switches-sockets",
    icon: "🔲",
    description: "Quality switches, sockets, and electrical accessories for modern homes.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
  {
    name: "Other Construction Items",
    slug: "other-items",
    icon: "📦",
    description: "Additional construction materials and accessories for your project.",
    image: "/images/hero-bricks.jpg",
    featured: false,
  },
];

export function generateWhatsAppMessage(
  productName: string,
  category: string,
  price: string,
  productUrl?: string
) {
  return encodeURIComponent(
    `Assalam-o-Alaikum BrickPoint,\nI am interested in the following product:\n\nProduct: ${productName}\nCategory: ${category}\nPrice: ${price}\n\nPlease share availability, delivery details, and final quotation.\n\nThank you.`
  );
}

export function generateWhatsAppLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;
}
